import { Route, Routes } from 'react-router-dom'
import './App.css'
import CreateTodoItem from './pages/CreateTodoItem'
import Home from './pages/Home'
import LoginPage from './pages/Login'
import RegisterPage from './pages/Register'

function App() {
  return (
    <div className='container'>
      <Routes>
        <Route Route path='login' element={<LoginPage />} />
        <Route Route path='register' element={<RegisterPage />} />
        <Route Route path='home' element={<Home />} />
        <Route Route path='create-item' element={<CreateTodoItem />} />
      </Routes>
    </div>
  )
}

export default App
