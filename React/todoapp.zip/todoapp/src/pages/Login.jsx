import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { loginUser } from '../services/user'

function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate('')

  const onLogin = async () => {
    // console.log(`email=${email}`)
    // console.log(`password=${password}`)
    const result = await loginUser(email, password)
    console.log(result)
    if (result['status'] === 'success') {
      alert('welcome')
      navigate('/home')
    } else alert('User do not exist')
  }

  return (
    <div>
      <h1 style={{ marginTop: '20', textAlign: 'center' }}>Login</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='mb-3'>
            <label htmlFor=''>Email</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              className='form-control'
              type='text'
            />
          </div>
          <div className='mb-3'>
            <label htmlFor=''>Password</label>
            <input
              onChange={(e) => setPassword(e.target.value)}
              className='form-control'
              type='text'
            />
          </div>
          <div className='mt-3'>
            Dont have an account?<Link to='/register'>Register here</Link>
          </div>
          <button
            onClick={onLogin}
            className='form-control btn btn-success mt-3'
          >
            Submit
          </button>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default LoginPage
