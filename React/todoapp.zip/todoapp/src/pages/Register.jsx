import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { registerUser } from '../services/user'

function RegisterPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [firstname, setFirstname] = useState('')
  const [lastname, setLastname] = useState('')
  const navigate = useNavigate('')

  const onRegister = async () => {
    // console.log(`email=${email}`)
    // console.log(`password=${password}`)
    // console.log(`firstname=${firstname}`)
    // console.log(`lastname=${lastname}`)

    const result = await registerUser(firstname, lastname, email, password)
    if (result['status'] == 'success') {
      alert('successfully registered your account')
      navigate('/login')
    } else {
      alert(result['error'])
    }
  }
  return (
    <div>
      <h1 style={{ marginTop: '20', textAlign: 'center' }}>Register</h1>

      <div className='row'>
        <div className='col'></div>
        <div className='col'>
          <div className='mb-3'>
            <label htmlFor=''>Firstname</label>
            <input
              onChange={(e) => setFirstname(e.target.value)}
              className='form-control'
              type='text'
            />
          </div>
          <div className='mb-3'>
            <label htmlFor=''>Lastname</label>
            <input
              onChange={(e) => setLastname(e.target.value)}
              className='form-control'
              type='text'
            />
          </div>
          <div className='mb-3'>
            <label htmlFor=''>Email</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              className='form-control'
              type='email'
            />
          </div>

          <div className='mb-3'>
            <label htmlFor=''>Password</label>
            <input
              onChange={(e) => setPassword(e.target.value)}
              className='form-control'
              type='password'
            />
          </div>
          <div className='mt-3'>
            Already have an account?<Link to='/login'>Login Here</Link>
          </div>
          <button
            onClick={onRegister}
            className='form-control btn btn-success mt-3'
          >
            Submit
          </button>
        </div>
        <div className='col'></div>
      </div>
    </div>
  )
}

export default RegisterPage
