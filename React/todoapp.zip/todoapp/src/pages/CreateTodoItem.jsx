import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { createTodoItems } from '../services/todoitems'

function CreateTodoItem() {
  const [title, setTitle] = useState('')
  const [details, setDetails] = useState('')
  const navigate = useNavigate('')

  const onSave = async () => {
    const result = await createTodoItems(title, details)
    if (result['status'] == 'success') {
      alert('successfully created a todo item')
      navigate('/home')
    } else {
      alert(result['error'])
    }
  }
  return (
    <div className='container'>
      <h1 style={{ marginTop: 20, marginBottom: 20, textAlign: 'center' }}>
        Create ToDo Item
      </h1>
      <div className='mb-3'>
        <label htmlFor=''>Title</label>
        <input
          onChange={(e) => setTitle(e.target.value)}
          type='text'
          className='form-control'
        />
      </div>
      <div className='mb-3'>
        <label htmlFor=''>Details</label>
        <input
          onChange={(e) => setDetails(e.target.value)}
          type='text'
          rows='10'
          className='form-control'
        />
      </div>
      <button onClick={onSave} className='btn btn-success'>
        Add Item
      </button>
      <Link to='/home' className='btn btn-danger ms-2'>
        Cancel
      </Link>
    </div>
  )
}

export default CreateTodoItem
