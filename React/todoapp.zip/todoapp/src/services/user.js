import axios from 'axios'
const url = 'http://localhost:4000'
export async function loginUser(email, password) {
  const body = { email, password }

  try {
    const result = await axios.post(url + '/user/login', body)
    // console.log(result)
    return result.data
  } catch (ex) {
    console.log(ex)
  }
}

export async function registerUser(firstname, lastname, email, password) {
  const body = { firstname, lastname, email, password }

  try {
    const response = await axios.post(url + '/user/register', body)
    // console.log(result)
    return response.data
  } catch (ex) {
    console.log(ex)
  }
}
