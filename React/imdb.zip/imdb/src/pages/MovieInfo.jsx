import { useLocation } from 'react-router-dom'
import harry1 from './images/harrypotter1.jpg'
import harry2 from './images/harrypotter2.jpg'
import harry3 from './images/harrypotter3.jpg'
import harry4 from './images/harrypotter4.jpg'
import harry5 from './images/harrypotter5.jpg'
import harry6 from './images/harrypotter6.jpg'
import harry7 from './images/harrypotter7.jpg'

import hp3 from './images/askaban.jpg'
import hp2 from './images/chember.jpg'
import hp7 from './images/deadly.jpg'
import hp4 from './images/gobletoffire.jpg'
import hp6 from './images/halfblood.jpg'
import hp1 from './images/harry1.jpg'
import hp5 from './images/orderofpheonix.jpg'

import bstar from './images/bluestar.png'
import increase from './images/increase.png'
import star from './images/star.png'

function MovieInfo() {
  const location = useLocation()

  const info = [
    [
      harry1,
      hp1,
      'Harry Potter and the Philosophers Stone',
      8.8,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Richard Harris, Maggie Smith, Robbie Coltrane, Alan Rickman, Ralph Fiennes',
    ],
    [
      harry2,
      hp2,
      'Harry Potter and the Chamber of Secrets',
      9.2,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Kenneth Branagh, Maggie Smith, Robbie Coltrane, Alan Rickman, Jason Isaacs',
    ],
    [
      harry3,
      hp3,
      'Harry Potter and the Prisoner of Azkaban',
      8.5,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Gary Oldman, Maggie Smith, Robbie Coltrane, Alan Rickman, Emma Thompson',
    ],
    [
      harry4,
      hp4,
      'Harry Potter and the Goblet of Fire',
      8.2,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Ralph Fiennes, Maggie Smith, Robbie Coltrane, Brendan Gleeson, Imelda Staunton',
    ],
    [
      harry5,
      hp5,
      'Harry Potter and the Order of the Phoenix',
      9.5,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Imelda Staunton, Maggie Smith, Robbie Coltrane, Alan Rickman, Helena Bonham Carter',
    ],
    [
      harry6,
      hp6,
      'Harry Potter and the Half-Blood Prince',
      9.0,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Jim Broadbent, Maggie Smith, Robbie Coltrane, Alan Rickman, Helena Bonham Carter',
    ],
    [
      harry7,
      hp7,
      'Harry Potter and the Deathly Hallows',
      9.3,
      'Daniel Radcliffe, Rupert Grint, Emma Watson, Ralph Fiennes, Maggie Smith, Robbie Coltrane, Alan Rickman, Helena Bonham Carter',
    ],
  ]

  return (
    <div>
      <div className='container-fluid movieinfo'>
        <div className='row'>
          <div className='col-8'>
            <div>
              <b>Episode Guide</b>
            </div>
            <h1>{info[location.state][2]}</h1>
            <div>
              <span>Movie</span>
              <span> &nbsp;&nbsp;English</span>
              <span> &nbsp;&nbsp;TV-MA</span>
              <span> &nbsp;&nbsp;1h 50min</span>
            </div>
            <div>
              <b>Cast : </b>
              {info[location.state][4]}
            </div>
          </div>
          <div className='col'>
            <div className='row'>
              <div className='col' style={{ textAlign: 'center' }}>
                <div>IMDb Rating</div>
                <img src={star} alt='' height={30} />
                <a style={{ fontSize: '22px' }}>
                  <b> &nbsp; {info[location.state][3]}</b>/10
                </a>
              </div>
              <div className='col' style={{ textAlign: 'center' }}>
                <div>Your Rating</div>
                <img src={bstar} alt='' height={30} />
                <a style={{ fontSize: '22px', color: '#2B7DBE' }}>
                  <b> &nbsp; Rate</b>
                </a>
              </div>
              <div className='col' style={{ textAlign: 'center' }}>
                <div>Popularity</div>
                <img src={increase} alt='' height={30} />
                <a style={{ fontSize: '22px', color: '#00AB0F' }}>
                  <b> &nbsp; 45</b>
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className='row mt-1'>
          <div className='col'>
            <img src={info[location.state][0]} alt='' height={400} />
          </div>
          <div className='col'>
            <img
              src={info[location.state][1]}
              alt=''
              height={400}
              width={700}
            />
          </div>
          <div className='col'>
            <div className='movieinfodiv'>+99 videos</div>
            <div className='movieinfodiv mt-2'>+99 videos</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default MovieInfo
