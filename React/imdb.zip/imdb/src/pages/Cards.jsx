import { useNavigate } from 'react-router-dom'
import './style.css'
function Card(props) {
  const navigate = useNavigate()
  function toInfo() {
    let indexs = props.indexs
    navigate('/info', { state: indexs })
  }
  return (
    <div>
      <div className='moviecards '>
        <img src={props.img} alt='' width={195} onClick={toInfo} />
        <div className='moviecardstxt'>
          <div className='mt-2'>{props.title}</div>
          <button className='mt-2 btn btn-dark form-control btn-sm'>
            Watch Option
          </button>
          <div className='mt-2'>Trailer</div>
        </div>
      </div>
    </div>
  )
}

export default Card
