import Card from './Cards'
import alladin from './images/Allahdin.jpg'
import avtar from './images/Avatar.jpg'
import img1 from './images/Avengers Engame.jpg'
import beauty from './images/Beautybeast.jpg'
import img2 from './images/Blackpanther.jpg'
import img3 from './images/OPPENHEIMER DESKTOP PC WALLPAPER 4K.jpg'
import img4 from './images/download (3).jpg'
import harry1 from './images/harrypotter1.jpg'
import harry2 from './images/harrypotter2.jpg'
import harry3 from './images/harrypotter3.jpg'
import harry4 from './images/harrypotter4.jpg'
import harry5 from './images/harrypotter5.jpg'
import harry6 from './images/harrypotter6.jpg'
import harry7 from './images/harrypotter7.jpg'
import play from './images/play-button.png'

function MainPage() {
  return (
    <div>
      <div className='row mt-2'>
        <div className='col-8'>
          <div id='carouselExample' className='carousel slide'>
            <div class='carousel-inner'>
              <div class='carousel-item active'>
                <div className='slide'>
                  <img src={img1} className='d-block w-100' alt='...' />
                  <p>Avengers Endgame</p>
                </div>
              </div>
              <div class='carousel-item'>
                <img src={img2} className='d-block w-100' alt='...' />
              </div>
              <div class='carousel-item'>
                <img src={img3} className='d-block w-100' alt='...' />
              </div>
              <div class='carousel-item'>
                <img src={img4} className='d-block w-100' alt='...' />
              </div>
            </div>
            <button
              className='carousel-control-prev'
              type='button'
              data-bs-target='#carouselExample'
              data-bs-slide='prev'
            >
              <span
                className='carousel-control-prev-icon'
                aria-hidden='true'
              ></span>
              <span className='visually-hidden'>Previous</span>
            </button>
            <button
              className='carousel-control-next'
              type='button'
              data-bs-target='#carouselExample'
              data-bs-slide='next'
            >
              <span
                className='carousel-control-next-icon'
                aria-hidden='true'
              ></span>
              <span className='visually-hidden'>Next</span>
            </button>
          </div>
        </div>
        <div className='col'>
          <div>
            <b style={{ color: 'yellow', fontSize: '20px' }}>Up Next</b>
            <div className='carddiv'>
              <div className='row mt-2'>
                <div className='col-4'>
                  <img src={avtar} alt='' height={150} />
                </div>
                <div className='col'>
                  <img src={play} alt='' height={30} />
                  <b> 1:59</b>

                  <div>
                    <b>Avatar</b>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                    Minus architecto earum
                  </div>
                </div>
              </div>

              <div className='row mt-2'>
                <div className='col-4'>
                  <img src={beauty} alt='' height={150} />
                </div>
                <div className='col'>
                  <img src={play} alt='' height={30} />
                  <b> 1:59</b>

                  <div>
                    <b>Avatar</b>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                    Minus architecto earum
                  </div>
                </div>
              </div>

              <div className='row mt-2'>
                <div className='col-4'>
                  <img src={alladin} alt='' height={150} />
                </div>
                <div className='col'>
                  <img src={play} alt='' height={30} />
                  <b> 1:59</b>

                  <div>
                    <b>Avatar</b>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                    Minus architecto earum
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <hr />
      <div style={{ display: 'flex', overflow: 'scroll' }}>
        <Card
          indexs='0'
          img={harry1}
          title='Harry Potter and the Philosophers Stone'
        />
        <Card
          indexs='1'
          img={harry2}
          title='Harry Potter and the Chamber of Secrets'
        />
        <Card
          indexs='2'
          img={harry3}
          title='Harry Potter and the Prisoner of Azkaban'
        />
        <Card
          indexs='3'
          img={harry4}
          title='Harry Potter and the Goblet of Fire'
        />
        <Card
          indexs='4'
          img={harry5}
          title='Harry Potter and the Order of the Phoenix'
        />
        <Card
          indexs='5'
          img={harry6}
          title='Harry Potter and the Half-Blood Prince'
        />
        <Card
          indexs='6'
          img={harry7}
          title='Harry Potter and the Deathly Hallows'
        />
      </div>

      <hr />
      <div style={{ display: 'flex', overflow: 'scroll' }}>
        <Card
          indexs='0'
          img={harry1}
          title='Harry Potter and the Philosophers Stone'
        />
        <Card
          indexs='1'
          img={harry2}
          title='Harry Potter and the Chamber of Secrets'
        />
        <Card
          indexs='2'
          img={harry3}
          title='Harry Potter and the Prisoner of Azkaban'
        />
        <Card
          indexs='3'
          img={harry4}
          title='Harry Potter and the Goblet of Fire'
        />
        <Card
          indexs='4'
          img={harry5}
          title='Harry Potter and the Order of the Phoenix'
        />
        <Card
          indexs='5'
          img={harry6}
          title='Harry Potter and the Half-Blood Prince'
        />
        <Card
          indexs='6'
          img={harry7}
          title='Harry Potter and the Deathly Hallows'
        />
      </div>
    </div>
  )
}

export default MainPage
