import { Route, Routes } from 'react-router-dom'
import './App.css'
import MainPage from './pages/MainPage'
import watchlist from './pages/images/bookmark.png'
import logo from './pages/images/imdblogo.png'
import imdbpro from './pages/images/imdbpro.png'
import more from './pages/images/more.png'
import search from './pages/images/search.png'

import Card from './pages/Cards'
import MovieInfo from './pages/MovieInfo'
import './pages/style.css'

function App() {
  return (
    <div>
      <header class='header'>
        <div class='containerr container-header'>
          <div class='logo-container border-white'>
            <div class='logo'>
              <img src={logo} alt='' height={35} />
            </div>
          </div>

          <div class='address-container'>
            <div class='icon-address'>
              <img src={more} alt='' height={19} />
              <p>
                <b> &nbsp;Menu</b>
              </p>
            </div>
          </div>

          <div class='search-container'>
            <select class='search-select'>
              <option>All</option>
            </select>
            <input type='text' class='search-input' placeholder='Search IMDb' />
            <div class='search-icon'>
              <img src={search} alt='' height={20} />
            </div>
          </div>

          <div class='language-container'>
            <div class='language-image'>
              <img src={imdbpro} alt='' height={40} />
            </div>
          </div>

          <div class='login-container'>
            <img src={watchlist} alt='' height={20} />
            <a className='atag' href='login.html'>
              &nbsp;Watchlist
            </a>
          </div>

          <div class='orders-container'>
            <a className='atag' href='#'>
              Sign In
            </a>
          </div>

          <div class='cart-container'>
            <a className='atag'>EN</a>
          </div>
        </div>
      </header>

      <Routes>
        <Route path='main' element={<MainPage />} />
        <Route path='card' element={<Card />} />
        <Route path='info' element={<MovieInfo />} />
      </Routes>
    </div>
  )
}

export default App
