import dress1 from './images/dress1.jpg'
import dress2 from './images/dress2.jpg'
import dress3 from './images/dress3.jpg'
import earing1 from './images/earings1.jpg'
import earing2 from './images/earings2.jpg'
import earing3 from './images/earings3.jpg'
import earing4 from './images/earings4.jpg'
const list = [
  {
    id: 1,
    title: 'Maxi Dress',
    author: 'by Wonder House Books | 25 April 2018',
    price: 1189,
    img: dress1,
    amount: 1,
  },
  {
    id: 2,
    title: 'Long Gown',
    author: 'by Maple Press  | 1 September 2020',
    price: 1298,
    img: dress2,
    amount: 1,
  },
  {
    id: 3,
    title: 'Summer Dress',
    author: 'by Om Books Editorial Team  | 25 November 2018',
    price: 2143,
    img: dress3,
    amount: 1,
  },
  {
    id: 4,
    title: 'Hooped Earings',
    author: 'by Wonder House Books | 25 April 2018',
    price: 457,
    img: earing1,
    amount: 1,
  },
  {
    id: 5,
    title: 'Stud Earings',
    author: 'by Wonder House Books  | 1 January 2018',
    price: 1149,
    img: earing2,
    amount: 1,
  },
  {
    id: 6,
    title: 'Gold Plated Earings',
    author: 'by Om Books Editorial Team | 30 September 2020',
    price: 3135,
    img: earing3,
    amount: 1,
  },
  {
    id: 7,
    title: 'Silver Earings',
    author: 'by Om Books Editorial Team  | 1 January 2021',
    price: 3693,
    img: earing4,
    amount: 1,
  },
  {
    id: 8,
    title: 'Silver Earings',
    author: 'by Om Books Editorial Team  | 1 January 2021',
    price: 3693,
    img: dress1,
    amount: 1,
  },
]

export default list
