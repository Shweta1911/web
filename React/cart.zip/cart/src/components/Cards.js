import React from 'react'
import '../styles/cards.css'

const Cards = ({ item, handleClick }) => {
  const { title, author, price, img } = item
  return (
    <div>
      <div className='cards'>
        <div className='image_box'>
          <div style={{ textAlign: 'center' }}>
            <img src={img} alt='Image' />
          </div>
        </div>
        <div className='details'>
          <p>{title}</p>
          <p>Price - {price}Rs</p>
          <button onClick={() => handleClick(item)} className='btn btn-warning'>
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  )
}

export default Cards
