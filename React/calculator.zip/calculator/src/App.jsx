import 'bootstrap/dist/css/bootstrap.css'
import './App.css'
import Calculator from './pages/Calculator'
function App() {
  return (
    <div>
      <Calculator />
    </div>
  )
}

export default App
