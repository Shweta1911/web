import { useState } from 'react'
import './calculator.css'
function Calculator() {
  let [value, setValue] = useState('')
  function getResult() {
    console.log(value)
    if (value.includes('sin')) {
      const thenum = value.replace(/^\D+/g, '')
      const val = parseInt(thenum.slice(0, thenum.length - 1))
      setValue(Math.sin(val * 0.0174533))
    } else if (value.includes('cos')) {
      const thenum = value.replace(/^\D+/g, '')
      const val = parseInt(thenum.slice(0, thenum.length - 1))
      setValue(Math.cos(val * 0.0174533))
    } else if (value.includes('tan')) {
      const thenum = value.replace(/^\D+/g, '')
      const val = parseInt(thenum.slice(0, thenum.length - 1))
      setValue(Math.tan(val * 0.0174533))
    } else if (value.includes('log')) {
      const thenum = value.replace(/^\D+/g, '')
      const val = parseInt(thenum.slice(0, thenum.length - 1))
      setValue(Math.log10(val))
    } else {
      setValue(eval(value))
    }
  }

  return (
    <div>
      <h1>Calculator</h1>

      <div className='container maxwid'>
        <br />
        <br />
        <input type='text' className='form-control' value={value} />
        <br />
        <div className='row'>
          <div className='col '>
            <div className='btnwidth'>
              <input
                onClick={(e) => setValue('')}
                type='button'
                value='AC'
                className='btn btn-success '
              />
              <input
                onClick={(e) => setValue(value.slice(0, -1))}
                type='button'
                value='DE'
                className='btn btn-danger '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='%'
                className='btn btn-primary '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='/'
                className='btn btn-primary '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='sin'
                className='btn btn-warning '
              />
            </div>
            <div className='btnwidth'>
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='7'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='8'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='9'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='*'
                className='btn btn-primary '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='cos'
                className='btn btn-warning '
              />
            </div>

            <div className='btnwidth'>
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='4'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='5'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='6'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='-'
                className='btn btn-primary '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='tan'
                className='btn btn-warning '
              />
            </div>

            <div className='btnwidth'>
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='1'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='2'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='3'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='+'
                className='btn btn-primary '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='log'
                className='btn btn-warning '
              />
            </div>

            <div className='btnwidth'>
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='('
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value=')'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='0'
                className='btn btn-dark '
              />
              <input
                onClick={(e) => setValue(value + e.target.value)}
                type='button'
                value='.'
                className='btn btn-primary '
              />
              <input
                //    onClick={(e) => setValue(eval(value))}
                onClick={getResult}
                type='button'
                value='='
                className='btn btn-primary '
              />
            </div>
            <br />
            <br />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Calculator
