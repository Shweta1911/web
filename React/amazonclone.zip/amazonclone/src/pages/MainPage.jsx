import img4 from './slider/book4.jpg'
import img5 from './slider/game5.jpg'
import img2 from './slider/kit3.jpg'
import img3 from './slider/lunar2.jpg'
import img1 from './slider/val.jpg'

import Card from './Card'
import dress1 from './images/dress1.jpg'
import dress2 from './images/dress2.jpg'
import dress3 from './images/dress3.jpg'
import earing1 from './images/earings1.jpg'
import earing2 from './images/earings2.jpg'
import earing3 from './images/earings3.jpg'
import earing4 from './images/earings4.jpg'

function MainPage() {
  return (
    <div>
      <div
        id='carouselExampleControls'
        class='carousel slide'
        data-ride='carousel'
      >
        <div class='carousel-inner'>
          <div class='carousel-item active'>
            <img class='d-block w-100' src={img1} alt='First slide' />
          </div>
          <div class='carousel-item'>
            <img class='d-block w-100' src={img2} alt='Second slide' />
          </div>
          <div class='carousel-item'>
            <img class='d-block w-100' src={img3} alt='Third slide' />
          </div>
          <div class='carousel-item'>
            <img class='d-block w-100' src={img4} alt='Third slide' />
          </div>
          <div class='carousel-item'>
            <img class='d-block w-100' src={img5} alt='Third slide' />
          </div>
        </div>
        <a
          class='carousel-control-prev'
          href='#carouselExampleControls'
          role='button'
          data-slide='prev'
        >
          <span class='carousel-control-prev-icon' aria-hidden='true'></span>
          <span class='sr-only'>Previous</span>
        </a>
        <a
          class='carousel-control-next'
          href='#carouselExampleControls'
          role='button'
          data-slide='next'
        >
          <span class='carousel-control-next-icon' aria-hidden='true'></span>
          <span class='sr-only'>Next</span>
        </a>
      </div>
      <div style={{ display: 'flex' }}>
        <Card indexs='0' title='Maxi Dress' price='49.99' img={dress1} />
        <Card indexs='1' title='Cocktail Dress' price='49.99' img={dress2} />
        <Card indexs='2' title='Summer Dress' price='49.99' img={dress3} />
        <Card indexs='3' title='Floral Dress' price='49.99' img={earing1} />
      </div>
      <div style={{ display: 'flex' }}>
        <Card indexs='4' title='Stud Earings' price='49.99' img={earing2} />
        <Card indexs='5' title='Hoop Earings' price='49.99' img={earing3} />
        <Card indexs='6' title='Dangling Earings' price='49.99' img={earing4} />
        <Card indexs='7' title='Maxi Dress' price='49.99' img={dress1} />
      </div>
    </div>
  )
}
export default MainPage
