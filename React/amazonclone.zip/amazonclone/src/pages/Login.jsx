import logo from './images/logo.png'
import './styles/style.css'

function LoginPage() {
  return (
    <div className='container'>
      <div class='container width'>
        <img src={logo} className='logo1' />
        <div class='divcard'>
          <div class='form'>
            <h3>Sign In</h3>
            <br />
            <div>
              <b>Email or mobile phone number</b>
            </div>
            <input type='text' class='form-control' />
            <button class='btn btn-warning btn-sm btn-block form-control mt-2'>
              Continue
            </button>
            <span>
              <div class='mt-3'>
                By continuing, you agree to Amazon's{' '}
                <a href=''>Conditions of Use</a> and
                <a href=''>Privacy Notice.</a>
              </div>
            </span>
            <br />
            <a href=''>Need help?</a>
            <hr />
            <div>
              <b>Buying for work?</b>
            </div>
            <div>
              <a href=''>Shop on Amazon Business</a>
            </div>
          </div>
          <br />
        </div>
        <br />
        <div class='help'>
          <span>New to Amazon?</span>
        </div>
        <button class='btn btn-light btn-sm form-control mt-3 a1'>
          <a href='register.html'>Create a Account </a>
        </button>
        <br />
      </div>
      <br />
      <br />
      <footer>
        <span>
          <a href=''>Conditions of Use </a>
          <a href=''>Privacy Notice </a>
          <a href=''>Help </a>
        </span>
        <div>© 1996-2024, Amazon.com, Inc. or its affiliates</div>
      </footer>
    </div>
  )
}
export default LoginPage
