import dress1 from './images/dress1.jpg'
import dress2 from './images/dress2.jpg'
import dress3 from './images/dress3.jpg'
import earing1 from './images/earings1.jpg'
import earing2 from './images/earings2.jpg'
import earing3 from './images/earings3.jpg'
import earing4 from './images/earings4.jpg'
function CartPage(props) {
  const product = [
    ['Maxi Dress', '49.99', dress1],
    ['Cocktail Dress', '79.99', dress2],
    ['Summer Dress', '34.99', dress3],
    ['Floral Dress', '59.99', earing1],
    ['Stud Earings', '49.99', earing2],
    ['Hoop Earings', '79.99', earing3],
    ['Dangling Earings', '34.99', earing4],
  ]
  console.log(props.elements)

  return (
    <div>
      <div class='row'>
        <div class='col-3'>
          <img src={dress1} alt='' height='250' />
        </div>
        <div class='col-8'>
          <div>
            <h3>
              Aahwan Red Solid Ruched Detail A-line Mini Dress for Women's &
              Girls' (194-Red-L)
            </h3>
            <div class='greenf'>In stock</div>
            <div>Eligible for FREE Shipping</div>
            <div style={{ display: 'flex' }}>
              <input type='checkbox' name='' id='' />
              <div>
                This will be a gift <a href=''>Learn more</a>
              </div>
            </div>
            <div>
              <b>Size:</b> L
            </div>
            <div>
              <b>Colour:</b> Red
            </div>

            <div style={{ display: 'flex' }}>
              <div class='dropdown'>
                <button
                  class='btn btn-light btn-sm dropdown-toggle '
                  type='button'
                  id='dropdownMenuButton'
                  data-toggle='dropdown'
                  aria-haspopup='true'
                  aria-expanded='false'
                >
                  Qut : 1
                </button>
              </div>

              <div>Delete </div>
              <div> | </div>
              <div> Save for later </div>
              <div> | </div>
              <div> See more like this </div>
              <div> | </div>
              <div> Share </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default CartPage
