import { useState } from 'react'
import './styles/style1.css'

function Card(props) {
  const [cartItems, setCartItems] = useState([])

  function addToCart() {
    // Access the index from props or other sources
    const selectedIndex = props.indexs // Assuming index is in props

    setCartItems((prevItems) => [...prevItems, selectedIndex])
  }

  return (
    <div>
      <div className='maincards'>
        <h5>
          <b>{props.title}</b>
        </h5>
        <div className='align'>
          <img src={props.img} alt='' />
        </div>
        <div className='mt-2'>{props.price}</div>
        <button onClick={addToCart} className='btn btn-warning'>
          Add to Cart
        </button>
      </div>
    </div>
  )
}

export default Card
