import i from './images/i.png'
import logo from './images/logo.png'
import './styles/style.css'

function RegisterPage() {
  return (
    <div>
      <div class='container width'>
        <img src={logo} className='logo1' alt='react logo' />
        <div class='divcard'>
          <div class='form'>
            <h3>Create Account</h3>
            <br />

            <div>
              <b>Your Name</b>
            </div>
            <input
              type='text'
              class='form-control mb-2'
              placeholder='First and last name'
            />

            <div>
              <b>Mobile Number</b>
            </div>
            <div className='flex'>
              <div class='dropdown'>
                <button
                  class='btn btn-light btn-sm dropdown-toggle '
                  type='button'
                  id='dropdownMenuButton'
                  data-toggle='dropdown'
                  aria-haspopup='true'
                  aria-expanded='false'
                >
                  +91
                </button>
              </div>
              <input
                type='text'
                class='form-control mb-2'
                placeholder='Mobile number'
              />
            </div>

            <div>
              <b>Email (optional)</b>
            </div>
            <input
              type='text'
              class='form-control mb-2'
              placeholder='First and last name'
            />

            <div>
              <b>Password</b>
            </div>
            <input
              type='text'
              class='form-control mb-2'
              placeholder='First and last name'
            />
            <div className='flex'>
              <img src={i} alt='' className='height15' />
              <div>Passwords must be at least 6 characters</div>
            </div>

            <br />
            <div>
              To verify your number, we will send you a text message with a
              temporary code. Message and data rates may apply.
            </div>
            <button class='btn btn-warning btn-sm btn-block form-control mt-2'>
              Verify mobile number
            </button>
            <br />
            <br />
            <hr />
            <span>
              <div>
                Already have an account? <a href=''>Sign in</a>
              </div>
            </span>
            <span>
              <div>
                Buying for work? <a href=''>Create a free business account</a>
              </div>
            </span>
            <br />
            <span>
              <div>
                By creating an account or logging in, you agree to Amazon’s
                <a href=''>Conditions of Use </a>and
                <a href=''>Privacy Policy.</a>
              </div>
            </span>
          </div>
          <br />
        </div>
      </div>
    </div>
  )
}
export default RegisterPage
