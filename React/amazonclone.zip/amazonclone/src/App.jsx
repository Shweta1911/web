import { Link, Route, Routes, useNavigate } from 'react-router-dom'
import './App.css'
import Card from './pages/Card'
import CartPage from './pages/Cart'
import LoginPage from './pages/Login'
import MainPage from './pages/MainPage'
import RegisterPage from './pages/Register'
import india from './pages/images/india.png'
import location from './pages/images/location.png'
import cart from './pages/images/shopping-cart.png'
import './pages/styles/style1.css'

function App() {
  const navigate = useNavigate()
  function toCart() {
    navigate('/cart')
  }
  return (
    <div>
      <header class='header'>
        <div class='containerr container-header'>
          <div class='logo-container border-white'>
            <div class='logo'></div>
            <span class='dotin'>.in</span>
          </div>

          <div class='address-container'>
            <p class='hello'>Deliver to</p>
            <div class='icon-address'>
              <img src={location} alt='' height='20px' />
              <p>
                <b>India</b>
              </p>
            </div>
          </div>

          <div class='search-container'>
            <select class='search-select'>
              <option>All</option>
            </select>
            <input type='text' class='search-input' />
            <div class='search-icon'>
              <i class='fa-solid fa-magnifying-glass'></i>
            </div>
          </div>

          <div class='language-container'>
            <div class='language-image'>
              <img src={india} />
              <p>Eng</p>
            </div>
          </div>

          <div class='login-container'>
            <p>Hello,Signin</p>
            <a className='atag' href='login.html'>
              Accounts & Lists
            </a>
          </div>

          <div class='orders-container'>
            <p>Returns</p>
            <a className='atag' href='#'>
              & Orders
            </a>
          </div>

          <div class='cart-container'>
            <img onClick={toCart} src={cart} alt='' height='30px' />
            <a className='atag' href='cartMain.html'>
              {' '}
              Cart
            </a>
          </div>
        </div>
      </header>
      <Routes>
        <Route path='login' element={<LoginPage />} />
        <Route path='register' element={<RegisterPage />} />
        <Route path='main' element={<MainPage />} />
        <Route path='cart' element={<CartPage />} />
        <Route path='card' element={<Card />} />
      </Routes>
      <Link to='/login'>Login</Link>
      <Link to='/register'>Register</Link>
      <Link to='/main'>Main</Link>
      <Link to='/cart'>Cart</Link>
    </div>
  )
}

export default App
