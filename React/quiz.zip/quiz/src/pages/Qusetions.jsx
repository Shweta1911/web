import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './style.css'
function Question() {
  const [value, setValue] = useState(0)
  const [option, setOption] = useState(0)
  const [score, setScore] = useState(0)
  const navigate = useNavigate()

  const question = [
    [
      'Which of the following is used in React.js to increase performance?',
      'Virtual DOM',
      'Original DOM',
      'Both A and B',
      'None',
      '1',
    ],
    [
      "What's the purpose of the Virtual DOM in React.js?",
      'To directly update the real DOM for every state change.',
      'To create an in-memory representation of the UI for efficient updates.',
      'To store historical states of the component.',
      'To handle user interactions with the UI.',
      '2',
    ],
    [
      'What is the correct way to render a React component inside another component?',
      '<AnotherComponent />',
      'renderComponent(AnotherComponent)',
      'ReactDOM.render(<AnotherComponent />, document.getElementById("root"))',
      'Both A and C',
      '4',
    ],
    [
      'What function is used to change the state in a React component?',
      'setState()',
      'changeState()',
      'updateState()',
      'modifyState()',
      '1',
    ],
    [
      'In React, props are:',
      'Immutable',
      'Mutable',
      'Both A and B',
      'None of the above',
      '1',
    ],
    [
      'What lifecycle method is invoked immediately after a component is mounted?',
      'componentWillMount()',
      'componentDidMount()',
      'componentDidUpdate()',
      'componentWillUnmount()',
      '2',
    ],
    [
      'In React, how can you prevent a component from rendering?',
      'Return null from render()',
      'Use a conditional statement inside render()',
      'Both A and B',
      'None of the above',
      '3',
    ],
    [
      'What is the purpose of keys in React lists?',
      'To identify list items uniquely',
      'To order list items',
      'To specify styles for list items',
      'To loop through the list items',
      '1',
    ],
    [
      'How can you pass data from a parent component to a child component in React?',
      'Using state',
      'Using props',
      'Using refs',
      'Using context',
      '2',
    ],
    [
      'What is the correct way to handle forms in React?',
      'Using refs',
      'Using state',
      'Using props',
      'Both A and B',
      '2',
    ],
  ]
  function prevQue() {
    setValue(value - 1)
  }
  function saveQue() {
    if (option === question[value][5]) {
      setScore(score + 1)
      console.log(score)
    }
    console.log(value)

    if (value === 9) {
      navigate('/score', { state: score })
    }
    setValue(value + 1)
  }
  return (
    <div>
      <div className='container mainContainer'>
        <div>
          <br />
          <b>Question {value + 1} : </b>
          {question[value][0]}
          <br />
          <div>
            <div class='form-check form-control mt-3'>
              <input
                onClick={(e) => setOption(e.target.value)}
                value={1}
                class='form-check-input mx-1'
                type='radio'
                name='option'
              />
              <label class='form-check-label mx-3'>{question[value][1]}</label>
            </div>
            <div class='form-check form-control mt-3'>
              <input
                onClick={(e) => setOption(e.target.value)}
                value={2}
                class='form-check-input mx-1'
                type='radio'
                name='option'
              />
              <label class='form-check-label mx-3'>{question[value][2]}</label>
            </div>
            <div class='form-check form-control mt-3'>
              <input
                onClick={(e) => setOption(e.target.value)}
                value={3}
                class='form-check-input mx-1'
                type='radio'
                name='option'
              />
              <label class='form-check-label mx-3'>{question[value][3]}</label>
            </div>
            <div class='form-check form-control mt-3'>
              <input
                onClick={(e) => setOption(e.target.value)}
                value={4}
                class='form-check-input mx-1'
                type='radio'
                name='option'
              />
              <label class='form-check-label mx-3'>{question[value][4]}</label>
            </div>
          </div>
        </div>
        <br />
        <button onClick={prevQue} className='btn btn-lg btn-warning'>
          Prev
        </button>
        <button onClick={saveQue} className='btn btn-lg btn-success'>
          Save
        </button>
      </div>
    </div>
  )
}

export default Question
