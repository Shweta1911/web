import { useLocation, useNavigate } from 'react-router-dom'
import './style.css'

function Score() {
  const location = useLocation()
  const navigate = useNavigate()

  function backBtn() {
    navigate('/question')
  }
  return (
    <div className='container score'>
      <h1>Your score is {location.state}</h1>
      <br />
      <br />
      <button onClick={backBtn} className='btn btn-lg btn-danger'>
        Back
      </button>
    </div>
  )
}

export default Score
