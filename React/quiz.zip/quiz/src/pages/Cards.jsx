import './style.css'
function Card() {
  return (
    <div>
      <div className='moviecards'>
        <div>Title</div>
        <button>Watch Option</button>
      </div>
    </div>
  )
}

export default Card
