import 'bootstrap/dist/css/bootstrap.css'
import { Route, Routes } from 'react-router-dom'
import './App.css'
import Question from './pages/Qusetions'
import Score from './pages/Score'

function App() {
  return (
    <div>
      <Routes>
        <Route path='question' element={<Question />} />
        <Route path='score' element={<Score />} />
      </Routes>
    </div>
  )
}

export default App
