import './App.css'

function App() {
  return (
    <div className='container-fluid'>
      <div className='row'>
        <div className='col-4 col1 '>
          <img
            src='	https://m.media-amazon.com/images/I/61CGHv6kmWL._AC_SL1000_.jpg'
            alt=''
            height={380}
          />
        </div>
        <div className='col-5 col2'>
          <h4>
            BENGOO G9000 Stereo Gaming Headset for PS4 PC Xbox One PS5
            Controller, Noise Cancelling Over Ear Headphones with Mic, LED
            Light, Bass Surround, Soft Memory Earmuffs (Blue)
          </h4>
          <a href=''>Visit the BENGOO Store</a>
          <br />
          <img src={require('./images\\stars.png')} alt='' height={32} />
          <a href=''> 104,379 ratings </a>
          <a href=''> | </a>
          <a href=''> Search this page </a>
          <br />
          <img src={require('./images\\bestseller.png')} alt='' height={20} />
          <a href=''>in Xbox One Headsets</a>
          <div className='fontsmall'>10K+ bought in past month</div>
          <hr />
          <div className='row'>
            <div className='col-2 price'>
              <div>List Price :</div>
              <div>Price :</div>
              <div>You Save :</div>
            </div>
            <div className='col'>
              <div style={{ fontSize: 14, color: 'gray' }}>39.99 </div>
              <div style={{ color: 'brown' }}> $25.99</div>
              <div style={{ color: 'brown' }}>$14.00 (35%)</div>
            </div>
          </div>
          <a href=''>Join Prime to buy this item at $22.99</a>

          <br />
          <br />
          <div>
            Colour :<b>Black</b>
          </div>

          <img src={require('./images\\types.png')} alt='' height={120} />
          <br />
          <div className='row'>
            <div className='col-3 '>
              <div>
                <b>Brand</b>
              </div>
              <div>
                <b>Model Name</b>
              </div>
              <div>
                <b>Color</b>
              </div>
              <div>
                <b>Form Factor</b>
              </div>
              <div>
                <b>Connectivity Technology</b>
              </div>
            </div>

            <div className='col'>
              <div> BENGOO</div>
              <div> G9000</div>
              <div>Black</div>
              <div>Over Ear</div>
              <div>Wired</div>
            </div>
          </div>

          <hr />
          <div>
            <div>
              <b>About this item</b>
            </div>
            <ul>
              <li>
                【Multi-Platform Compatible】Support PlayStation 4, New Xbox
                One, PC, Nintendo 3DS, Laptop, PSP, Tablet, iPad, Computer,
                Mobile Phone. Please note you need an extra Microsoft Adapter
                (Not Included) when connect with an old version Xbox One
                controller.
              </li>
              <li>
                【Surrounding Stereo Subwoofer】Clear sound operating strong
                brass, splendid ambient noise isolation and high precision 40mm
                magnetic neodymium driver, acoustic positioning precision
                enhance the sensitivity of the speaker unit, bringing you vivid
                sound field, sound clarity, shock feeling sound. Perfect for
                various games like Halo 5 Guardians, Metal Gear Solid, Call of
                Duty, Star Wars Battlefront, Overwatch, World of Warcraft
                Legion, etc.
              </li>
              <li>
                【Noise Isolating Microphone】Headset integrated
                onmi-directional microphone can transmits high quality
                communication with its premium noise-concellng feature, can pick
                up sounds with great sensitivity and remove the noise, which
                enables you clearly deliver or receive messages while you are in
                a game. Long flexible mic design very convenient to adjust angle
                of the microphone.
              </li>
              <li>
                【Great Humanized Design】Superior comfortable and good air
                permeability protein over-ear pads, muti-points headbeam, acord
                with human body engineering specification can reduce hearing
                impairment and heat sweat.Skin friendly leather material for a
                longer period of wearing. Glaring LED lights desigend on the
                earcups to highlight game atmosphere.
              </li>
              <li>
                【Effortlessly Volume Control】High tensile strength,
                anti-winding braided USB cable with rotary volume controller and
                key microphone mute effectively prevents the 49-inches long
                cable from twining and allows you to control the volume easily
                and mute the mic as effortless volume control one key mute.
              </li>
            </ul>

            <div>
              <b>Note:</b> Products with electrical plugs are designed for use
              in the US. Outlets and voltage differ internationally and this
              product may require an adapter or converter for use in your
              destination. Please check compatibility before purchasing.
            </div>
          </div>
        </div>
        <div className='col'>
          <div className='col3'>
            <h5 className='brown'>$25.99</h5>
            <div className='brown'>
              This item cannot be shipped to your selected delivery location.
              Please choose a different delivery location.
            </div>

            <a href='' className='fontsmall'>
              {' '}
              <img
                src={require('./images\\locationpin.png')}
                alt=''
                height={15}
              />
              Deliver to India
            </a>
            <br />
            <br />
            <h5 style={{ color: 'green' }}>In Stock</h5>

            <button className=' btn btn-sm btn-light form-control mt-3'>
              Quantity
            </button>
            <button className=' form-control btn btn-sm btn-warning mt-3'>
              See Similar Items
            </button>
            <div className='row fontsmall mt-3'>
              <div className='col-3 '>
                <div>Ships from</div>
                <div>Sold by</div>
                <div>Returns</div>
                <br />
                <div>Payment</div>
              </div>

              <div className='col mb-3'>
                <div>Amazon</div>
                <div className='blue'> Bengoo Inc.</div>
                <div className='blue'>
                  Eligible for Return, Refund or Replacement within 30 days of
                  receipt
                </div>
                <div className='blue'>Secure transaction</div>
              </div>
            </div>
            <span style={{ display: 'flex' }}>
              <input type='checkbox' />
              <div>Add a gift receipt for easy returns</div>
            </span>
            <hr />
            <button className=' btn btn-sm btn-light form-control '>
              Add to List
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
