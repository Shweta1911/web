# import numpy
import numpy as np


def function1():
    # list of numbers
    numbers_list = [10, 20, 30, 40, 50]
    print(f"numbers_list = {numbers_list}, type = {type(numbers_list)}")

    # tuple of numbers
    numbers_tuple = 10, 20, 30, 40, 50
    print(f"numbers_tuple = {numbers_tuple}, type = {type(numbers_tuple)}")

    # array of numbers
    numbers_array = np.array([10, 20, 30, 40, 50])
    print(f"numbers_array = {numbers_array}, type = {type(numbers_array)}")


# function1()


def function2():
    # array of numbers
    # - collection of similar values
    array = np.array([10, 20, 30, 40, 50])

    print(f"array = {array}")
    print(f"type = {type(array)}")
    print(f"# dimensions = {array.ndim}")
    print(f"length of array = {array.size}")
    print(f"type of every item of array = {array.dtype}")
    print(f"size of every item of array = {array.itemsize}")
    print(f"total memory required to store array = {array.itemsize * array.size} bytes")
    print(f"total memory required to store array = {array.nbytes} bytes")

    # shape = tuple contains (#rows, #cols) for 2d array
    # shape = tuple contains (#values,) for 1d array
    print(f"shape of array = {array.shape}")
    print(f"flags of array = {array.flags}")


# function2()


def function3():
    import sys

    def print_array_info(array):
        print(f"array = {array}")
        print(f"# dimensions = {array.ndim}")
        print(f"length of array = {array.size}")
        print(f"type of every item of array = {array.dtype}")
        print(f"size of every item of array = {array.itemsize}")
        print(f"total memory = {array.nbytes} bytes")
        print(f"shape of array = {array.shape}")
        print("-" * 80)

    # list of numbers
    numbers = [10, 20, 30, 40, 50]
    print(f"size of an element of list = {sys.getsizeof(numbers[0])} bytes")
    print(f"total memory required = {sys.getsizeof(numbers[0]) * len(numbers)} bytes")
    print("-" * 80)

    # array of numbers
    a1 = np.array(numbers)
    print_array_info(a1)

    # array of numbers
    # consider the type of every item as int64
    a2 = np.array(numbers, dtype=np.int64)
    print_array_info(a2)

    # array of numbers
    # consider the type of every item as int32
    a3 = np.array(numbers, dtype=np.int32)
    print_array_info(a3)

    # array of numbers
    # consider the type of every item as int16
    a4 = np.array(numbers, dtype=np.int16)
    print_array_info(a4)

    # array of numbers
    # consider the type of every item as int8
    a5 = np.array(numbers, dtype=np.int8)
    print_array_info(a5)


# function3()


