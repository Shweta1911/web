import numpy as np


def print_array_info(array):
    print(f"array = {array}")
    print(f"# dimensions = {array.ndim}")
    print(f"length of array = {array.size}")
    print(f"type of every item of array = {array.dtype}")
    print(f"size of every item of array = {array.itemsize}")
    print(f"total memory = {array.nbytes} bytes")
    print(f"shape of array = {array.shape}")
    print("-" * 80)


def function1():
    # 1d array of numbers
    array1 = np.array([10, 20, 30, 40, 50, 60])
    print_array_info(array1)

    # formula = base address + (index * itemsize)
    print(f"value at 0th index = {array1[0]}")
    print(f"value at 4th index = {array1[4]}")

    print()

    # 2d array of numbers
    array2 = np.array([
        [10, 20],
        [30, 40],
        [50, 60]]
    )
    print_array_info(array2)

    # row address = base address + (row index * item size * #columns)
    # 0th row address = 0x11000 + (0 * 4 * 2) = 0x11000
    # 1st row address = 0x11000 + (1 * 4 * 2) = 0x11008
    # 2nd row address = 0x11000 + (2 * 4 * 2) = 0x11016

    # address of [r][c] = rth row address + (col index * item size)
    # address of [2][1] = 2nd row address + (1 * 4) = 0x11016 + (4) = 0x11020
    # address of [1][0] = 1st row address + (0 * 4) = 0x1108
    print(f"value at [0][0] = {array2[0][0]}")
    print(f"value at [2][1] = {array2[2][1]}")
    print(f"value at [1][0] = {array2[1][0]}")
    print(f"value at [2][0] = {array2[2][0]}")


# function1()


def function2():
    # 1d array of numbers
    array1 = np.array([10, 20, 30, 40, 50, 60])
    print_array_info(array1)

    # reshape the array to 2d array
    array2 = array1.reshape((3, 2))
    print_array_info(array2)

    # reshape the array to 2d array
    array3 = array1.reshape((2, 3))
    print_array_info(array3)

    # reshape the array to 2d array
    array4 = array1.reshape((1, 6))
    print_array_info(array4)

    # reshape the array to 2d array
    array5 = array1.reshape((6, 1))
    print_array_info(array5)

    # reshape the array to 3d array
    array6 = array1.reshape((2, 3, 1))
    print_array_info(array6)


# function2()


def function3():
    # 1d array
    array1 = np.array([10, 20, 30, 50, 60])
    print_array_info(array1)

    # 2d array
    array2 = np.array([[10, 20], [30, 40], [50, 60]])
    print_array_info(array2)


# function3()


def function4():
    # create an array using arange
    array1 = np.arange(0, 10, 1)
    print(array1)

    # create an array using arange
    array2 = np.arange(10)
    print(array2)

    # create an array using arange
    array3 = np.arange(0, 10, 2)
    print(array3)


# function4()


def function5():
    # generate an array using 1s
    array1_float = np.ones(10)
    print(array1_float)

    array1_int = np.ones(10, dtype=np.int64)
    print(array1_int)

    # generate a 2d array using 1s
    array2_int = np.ones((5, 6), dtype=np.int64)
    print(array2_int)

    # generate an array using 0s
    array0_float = np.zeros(10)
    print(array0_float)

    array0_int = np.zeros(10, dtype=np.int64)
    print(array0_int)


# function5()


def function6():
    array1 = np.random.random(6)
    print(array1)

    array2 = np.random.randint(50, 100, 5)
    print(array2)


function6()


