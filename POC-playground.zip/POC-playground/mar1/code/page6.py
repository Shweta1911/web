import numpy as np
import pandas as pd


def function1():
    # list of numbers
    numbers = [10, 20, 30, 40, 50]
    print(f"numbers = {numbers}, type = {type(numbers)}")

    # tuple of numbers
    numbers_tuple = 10, 20, 30, 40, 50
    print(f"numbers_tuple = {numbers_tuple}, type = {type(numbers_tuple)}")

    # array of numbers
    array = np.array([10, 20, 30, 40, 50])
    print(f"array = {array}, type = {type(array)}")

    # series of numbers
    series = pd.Series([10, 20, 30, 40, 50])
    print(f"series = {series}, type = {type(series)}")


# function1()


def function2():
    # series of numbers
    # - one dimensional array
    # - collection of similar values (ndarray)
    series = pd.Series([10, 20, 30, 40, 50])
    print(series)
    print(f"index = {series.index}")
    print(f"values = {series.values}")
    print(f"dtype = {series.dtype}")
    print(f"#dimensions = {series.ndim}")
    print(f"shape = {series.shape}")


# function2()


def function3():
    # models = pd.Series(['triber', 'alto', 'nano'])
    # companies = pd.Series(['renault', 'suzuki', 'tata'])

    # store models using company as index positions
    models = pd.Series(['triber', 'alto', 'nano'], index=['renault', 'suzuki', 'tata'])
    print(models)

    # get the model of tata
    print(f"models['tata'] = {models['tata']}")
    print(f"models['renault'] = {models['renault']}")

    # get the model of BMW
    # this statement will raise an exception
    # print(f"models['BMW'] = {models['BMW']}")

    print()

    # store companies using models as index positions
    companies = pd.Series(['renault', 'suzuki', 'tata'], index=['triber', 'alto', 'nano'])
    print(companies)
    # get company of triber
    print(f"companies['triber'] = {companies['triber']}")


# function3()


def function4():
    series = pd.Series([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    print(series)

    # indexing
    print(f"series[5] = {series[5]}")

    # this wont work any further as the -7 is missing
    # print(f"series[-7] = {series[-7]}")

    # multi-indexing
    # returns a new seres object with all the values
    print(f"series[[3, 6, 7, 8]] = {series[[3, 6, 7, 8]]}")

    # boolean indexing
    print(series[[False, False, False, True, False, False, True, True, True, False]])

    # filtering
    # get the values above 50
    print(f"series[series > 50] = {series[series > 50]}")

    # slicing
    # returns a new seres object with all the values
    print(f"series[3:8] = {series[3:8]}")


# function4()


def function5():
    # series using list
    s1 = pd.Series([10, 20, 30, 40, 50])
    print(f"s1 = {s1}")

    # series using tuple
    s2 = pd.Series((10, 20, 30, 40, 50))
    print(f"s2 = {s2}")

    # series using dictionary
    s3 = pd.Series({
        "apple": "iPhone",
        "samsung": "galaxy",
        "one plus": "one plus 18"
    })
    print(f"s3 = {s3}")

    # series using set
    # can not create a series using set
    # s4 = pd.Series({10, 20, 30, 40, 50})
    # print(s4)

    # series using array
    s5 = pd.Series(np.array([10, 20, 30, 40, 50]))
    print(f"s5 = {s5}")


function5()




