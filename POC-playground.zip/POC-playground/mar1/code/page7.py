# Data Frame
# - multi-dimensional collection
# - represents a tabular data structure having rows and columns
# - every column is a series

import pandas as pd


def function1():
    # 2D collection
    # - list of dictionaries
    persons = [
        {"name": "person1", "age": 20, "address": "pune"},
        {"name": "person2", "age": 22, "address": "mumbai"},
        {"name": "person3", "age": 23, "address": "satara"},
        {"name": "person4", "age": 25, "address": "sangli"},
    ]

    # create a data frame using list of dictionaries
    df = pd.DataFrame(persons)
    print(df)


# function1()


def function2():
    # read the data from a csv file
    df = pd.read_csv('./nba.csv')

    # print(df)

    # read first few (5) rows from df
    # print(df.head())
    # print(df.head(10))

    # read last few (5) rows from df
    # print(df.tail())
    # print(df.tail(10))

    # find the columns
    # print(df.columns)

    # describe the df - get the statistical information
    # print(df.describe())

    # get information of df
    # print(df.info())


# function2()


def function3():
    # read the data from a csv file
    df = pd.read_csv('./nba.csv')

    # print(df.info())
    # print(df.head())

    # check if df has any missing (na) values
    # print(df.isna())

    # get all the rows from a required column
    # print(df['Team'])

    # check if a column has got any NA values
    # print(df['Team'].isna())

    # replace a NA value with hardcoded value
    # df['Team'].fillna('boston college', inplace=True)
    # print(df['Team'])

    # replace the NA value with center points
    # center: mean (numeric), mode (textual) or median
    salary_mean = df['Salary'].mean()
    df['Salary'].fillna(salary_mean, inplace=True)
    # df_salary = df['Salary'].fillna(salary_mean)
    # print(df_salary)
    print(df.info())

    # get value count of column
    # print(df['Team'].value_counts())
    # mode = "New Orleans Pelicans"
    # df['Team'].fillna(mode, inplace=True)
    # print(df.info())

    # remove the rows having NA values
    # df.dropna(axis=0, inplace=True)

    # remove the columns having NA values
    # df.dropna(axis=1, inplace=True)

    # print(df.info())


# function3()


def function4():
    # read the data from a csv file
    df = pd.read_csv('./nba.csv')

    print(df.columns)

    # remove a column
    # df.drop('Position', axis=1, inplace=True)
    # print(df.columns)

    # remove multiple columns
    # df.drop(['Number', 'Position', 'Age'], axis=1, inplace=True)
    # print(df.columns)

    # add a new column
    df['Bonus'] = df['Salary'] * 0.1
    print(df)

    # create a new df using the column sequence
    df_new = df[['Bonus', 'Salary', 'Team']]

    # save all the changes into new file
    df_new.to_csv('new_nba.csv')


function4()
