import numpy as np


def function1():
    numbers1 = [10, 20, 30, 40, 50]
    numbers2 = [60, 70, 80, 90, 100]

    # this will perform extend operation
    numbers3 = numbers1 + numbers2
    print(numbers3)


# function1()


def function2():
    array = np.array([10, 20, 30, 40, 50])
    print(f"array = {array}")

    # broadcast operation
    # - the operation will be performed on every member of an array
    # - all mathematical operations are broadcast operations

    # mathematical operations
    print(f"array + 20 = {array + 20}")
    print(f"array - 20 = {array - 20}")
    print(f"array * 20 = {array * 20}")
    print(f"array / 20 = {array / 20}")
    print(f"array // 20 = {array // 20}")
    print(f"array ** 2 = {array ** 2}")

    print()

    # relations operations
    print(f"array > 50 = {array > 50}")
    print(f"array >= 50 = {array >= 50}")
    print(f"array < 50 = {array < 50}")
    print(f"array <= 50 = {array <= 50}")
    print(f"array == 50 = {array == 50}")
    print(f"array != 50 = {array != 50}")


# function2()


def function3():
    array1 = np.array([10, 20, 30, 40])
    array2 = np.array([50, 60, 70, 80])

    # operations performed on multiple arrays
    print(f"array1 + array2 = {array1 + array2}")
    print(f"array1 - array2 = {array1 - array2}")
    print(f"array1 * array2 = {array1 * array2}")
    print(f"array1 / array2 = {array1 / array2}")


function3()
