# generator
# - iterator created using a function
# - use yield

def function1():
    for index in range(10):
        yield index


generator = function1()
# print(f"generator = {generator}, type = {type(generator)}")
# print(f"next value = {next(generator)}")
for value in generator:
    print(f"value = {value}")


class MyClass:
    def __init__(self):
        self.__index = 0
        self.__collection = [10, 20, 30, 40, 50]

    def __iter__(self):
        self.__index = 0
        return self

    def __next__(self):
        if self.__index >= len(self.__collection):
            raise StopIteration

        value = self.__collection[self.__index]
        self.__index += 1
        return value


# my_class = MyClass()
# iterator = iter(my_class)
# print(f"next value = {next(iterator)}")
# print(f"next value = {next(iterator)}")
# print(f"next value = {next(iterator)}")
# print(f"next value = {next(iterator)}")
# print(f"next value = {next(iterator)}")
# print(f"next value = {next(iterator)}")

# for value in my_class:
#     print(f"value = {value}")

