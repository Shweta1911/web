# indexing
# - getting the data using index positions
#   - positive
#   - negative
#   - multi-indexing
#   - boolean
import numpy as np


def function1():
    array = np.arange(0, 10) * 10

    # multi-indexing
    print(f"get values from 3, 4, 8th position = {array[[3, 4, 8]]}")
    print(f"array[[7, 2, 1, 5]] = {array[[7, 2, 1, 5]]}")

    print(f"array[[-2, -5, -6]] = {array[[-2, -5, -6]]}")
    print(f"array[[-2, 3, -5, 5 -6]] = {array[[-2, 3, -5, 5, -6]]}")


# function1()


def function2():
    array = np.arange(0, 10) * 10

    # boolean indexing
    # get values from 3, 4, 8th position
    print(array[[False, False, False, True, True, False, False, False, True, False]])


# function2()


def function3():
    # filtering
    array = np.arange(0, 10) * 10
    print(f"array > 40 = {array > 40}")
    print(f"array[array > 40] = {array[array > 40]}")

    # salaries
    salaries = np.array([50, 20, 35, 10, 15, 19, 26, 80])
    print(f"salaries[salaries >= 50] = {salaries[salaries >= 50]}")


function3()


