# functional programming language
# - functions are considered as first class citizens
# - a function can be passed as an argument to another function
# - a function can be returned as a return value of a function

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
persons = [
    {"name": "person1", "age": 10, "city": "pune", "email": "p1@test.com"},
    {"name": "person2", "age": 30, "city": "nashik", "email": "p2@test.com"},
    {"name": "person3", "age": 40, "city": "satara", "email": "p3@test.com"},
    {"name": "person4", "age": 15, "city": "sangli", "email": "p4@test.com"},
]

def function1():
    # list of numbers
    print(numbers)

    # get square of every value inside the numbers collection
    square = lambda n: n ** 2
    squares = list(map(square, numbers))
    print(squares)

    cubes = list(map(lambda n: n ** 3, numbers))
    print(cubes)


# function1()


def function2():
    # get every person's name and city
    get_name_email_from_person = lambda person: {
        "name": person['name'],
        "city": person['city']
    }

    new_persons = list(map(get_name_email_from_person, persons))
    print(new_persons)


# function2()


def function3():
    # list of numbers
    print(numbers)

    # find all even numbers
    even_numbers = list(filter(lambda n: n % 2 == 0, numbers))
    print(even_numbers)

    # find all odd numbers
    odd_numbers = list(filter(lambda n: n % 2 != 0, numbers))
    print(odd_numbers)


# function3()


def function4():
    # find the persons from pune
    print(list(filter(lambda person: person['city'] == 'pune', persons)))

    # find the persons who are eligible for voting
    print(list(filter(lambda person: person['age'] >= 18, persons)))


# function4()


def function5():
    # list of numbers
    print(numbers)

    # get square of even numbers
    even_numbers = filter(lambda n: n % 2 == 0, numbers)
    square_even_numbers = list(map(lambda n: n ** 2, even_numbers))
    print(square_even_numbers)

    # get cube of odd numbers
    odd_numbers = filter(lambda n: n % 2 != 0, numbers)
    cube_odd_numbers = list(map(lambda n: n ** 3, odd_numbers))
    print(cube_odd_numbers)

    cube_odd_numbers = list(map(lambda n: n ** 3,
                                filter(lambda n: n % 2 != 0, numbers)))
    print(cube_odd_numbers)

    # get name and age of persons from sangli
    # get name and email of persons not eligible for voting


# function5()
