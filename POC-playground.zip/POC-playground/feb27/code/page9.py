# methods
# - initializer (constructor)
#   - type
#     - default initializer
#     - custom initializer (parameterized)
# - de-initializer (destructor)
# - setter
# - getter
# - facilitator

class Person:
    # def __init__(self):
    #     print("inside __init__")
    #     setattr(self, "name", "")
    #     setattr(self, "address", "")
    #     setattr(self, "age", 0)

    def __init__(self, name, address, age):
        setattr(self, "name", name)
        setattr(self, "address", address)
        setattr(self, "age", age)

    def print_info(self):
        print(f"name = {getattr(self, 'name')}")
        print(f"address = {getattr(self, 'address')}")
        print(f"age = {getattr(self, 'age')}")

    def can_vote(self):
        if getattr(self, 'age') >= 18:
            print(f"{getattr(self, 'name')} is eligible for voting")
        else:
            print(f"{getattr(self, 'name')} is NOT eligible for voting")


person = Person("person1", "pune", 30)
person.print_info()
person.can_vote()
