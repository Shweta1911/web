# comprehension
# - better syntax for both filter and map
# - types
#   - list comprehension
#   - tuple comprehension
#   - dictionary comprehension

# list of values
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# list of dictionaries
persons = [
    {"name": "person1", "age": 10, "city": "pune", "email": "p1@test.com"},
    {"name": "person2", "age": 30, "city": "nashik", "email": "p2@test.com"},
    {"name": "person3", "age": 40, "city": "satara", "email": "p3@test.com"},
    {"name": "person4", "age": 15, "city": "sangli", "email": "p4@test.com"},
]

def function1():
    # list comprehension as map function
    squares = [value ** 2 for value in numbers]
    print(f"numbers = {numbers}")
    print(f"squares = {squares}")

    # convert every distance in meters
    distances_cm = [1000, 3000, 45000, 6700, 9800]
    distances_m = [value / 100 for value in distances_cm]
    print(distances_cm)
    print(distances_m)


# function1()


def function2():
    # list comprehension as filter function
    even_numbers = [value for value in numbers if value % 2 == 0]
    print(f"even numbers = {even_numbers}")


# function2()


def function3():
    # list comprehension as filter and map functions
    # get square of even numbers
    square_even_numbers = [value ** 2 for value in numbers if value % 2 == 0]
    print(square_even_numbers)

    # get cube of odd numbers
    cube_odd_numbers = [value ** 3 for value in numbers if value % 2 != 0]
    print(cube_odd_numbers)

    # get name and email of persons who are eligible for voting
    persons_eligible_for_voting = [
        {"name": person['name'], "email": person["email"]}
            for person in persons if person['age'] >= 18
    ]
    print(persons_eligible_for_voting)


function3()
