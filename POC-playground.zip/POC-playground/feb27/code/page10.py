# access behaviors
# - private
#   - accessible ONLY inside the class
#   - use __ prefix for the attribute
# - protected
#   - accessible only in the same and derived class(es)
#   - use _ prefix for the attribute
# - public
#   - accessible inside or outside the class
#   - default behavior
#   - does not use any _ prefix for the attribute
# name mangling
# - compiler's technique used to hide the original name(s)

class Person:
    def __init__(self, name, address, age):
        self.__name = name
        self.__address = address
        self.__age = age

    def __del__(self):
        print("inside the __del__")

    def print_info(self):
        print(f"name = {self.__name}")
        print(f"address = {self.__address}")
        print(f"age = {self.__age}")


person = Person("person1", "pune", 10)
print(person.__dict__)

# person.age = -100
# person.__age = -100

# discouraged to be dependent on the internal working
# person._Person__age = -100
print(person.__dict__)
person.print_info()
