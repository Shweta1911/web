# collection
# - multi-dimensional
# - collection of collections
#   - list of lists
#   - list of tuples
#   - list of dictionaries
#   - tuple of tuples
#   - tuple of lists

def function1():
    # single dimensional list
    numbers = [10, 20, 30, 40, 50]
    print(numbers)
    print(f"value at 0th index = {numbers[0]}")
    for value in numbers:
        print(f"value = {value}")

    print('-' * 80)

    # two dimension list with size of 4x3
    numbers2 = [
        [10, 20, 30],
        [40, 50, 60],
        [70, 80, 90],
        [100, 110, 120]
    ]
    print(numbers2)
    print(f"value at 0th index = {numbers2[0]}")
    for inner_list in numbers2:
        for value in inner_list:
            print(f"value = {value}")
        print("")


# function1()


def function2():
    # two dimension list
    # list of lists
    numbers = [
        [10, 20, 30],
        [40, 50],
        [60, 70, 80, 90]
    ]
    for row in numbers:
        for value in row:
            print(value)
        print()


# function2()


def function3():
    # three dimension list
    # size: 2x2x2
    numbers = [
        [
            [10, 20],
            [30, 40]
        ],
        [
            [50, 60],
            [70, 80]
        ]
    ]

    for outer_row in numbers:
        for inner_row in outer_row:
            for value in inner_row:
                print(f"value = {value}")
            print()
        print()


function3()
