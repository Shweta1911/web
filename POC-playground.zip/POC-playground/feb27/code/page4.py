# dictionary
# - collection of key-value pairs
# - use {} to create a dictionary


def functino1():
    # dictionary
    person = {
        "name": "person1",
        "age": 30,
        "address": {
            "city": "pune",
            "state": "maharashtra",
            "country": "india",
            "zipcode": 411041
        },
        "email": "person1@test.com",
        "hobbies": ["reading books", "watching movies"],
        "can_vote": True
    }

    # get all keys
    print(person.keys())

    # get all values
    print(person.values())

    # get persons values using []
    # use this method when you are sure about the key's existence
    print(f"name = {person['name']}")
    print(f"age = {person['age']}")

    # use get method to get value from dictionary
    # print(f"phone = {person['phone']}")
    print(f"phone = {person.get('phone')}")

    print("")

    # get all the values along with their keys
    print(person.keys())
    for key in person.keys():
        print(f"value of {key} = {person[key]}")


# functino1()


def function2():
    # list of dictionaries
    persons = [
        {"name": "person1", "age": 20, "city": "pune"},
        {"name": "person2", "age": 30, "city": "nashik"},
        {"name": "person3", "age": 40, "city": "satara"},
        {"name": "person4", "age": 50, "city": "sangli"},
    ]
    # print(persons)

    # print all information about all persons
    for person in persons:
        # for key in person:
        #     print(f"{key} = {person[key]}")
        print(f"name = {person['name']}")
        print(f"age = {person['age']}")
        print(f"city = {person['city']}")
        print()


# function2()


def function3():
    # empty list
    l1 = []
    print(f"l1 = {l1}, type = {type(l1)}")

    # empty tuple
    t1 = ()
    print(f"t1 = {t1}, type = {type(t1)}")

    # empty set
    s1 = set()
    print(f"s1 = {s1}, type = {type(s1)}")

    # empty dictionary
    d1 = {}
    print(f"d1 = {d1}, type = {type(d1)}")


function3()
