# set
# - mutable
# - collection of unique values
# - use {} to create a set
# - does not maintain the insertion order (as it uses hash to store the data)
# frozen_set
# - immutable

def function1():
    # list of numbers
    numbers_list = [10, 20, 30, 40, 50, 10, 20, 30, 40, 50, 10, 20, 30, 40, 50]
    print(f"numbers_list = {numbers_list}, type = {type(numbers_list)}")

    # tuple of numbers
    numbers_tuple1 = (10, 20, 30, 40, 50, 10, 20, 30, 40, 50, 10, 20, 30, 40, 50)
    print(f"numbers_tuple1 = {numbers_tuple1}, type = {type(numbers_tuple1)}")

    numbers_tuple2 = 10, 20, 30, 40, 50, 10, 20, 30, 40, 50, 10, 20, 30, 40, 50
    print(f"numbers_tuple2 = {numbers_tuple2}, type = {type(numbers_tuple2)}")

    # set of numbers
    numbers_set = {10, 20, 30, 40, 50, 10, 20, 30, 40, 50, 10, 20, 30, 40, 50}
    print(f"numbers_set = {numbers_set}, type = {type(numbers_set)}")


# function1()


def function2():
    # sets
    s1 = {10, 20, 30, 40, 50}
    s2 = {40, 50, 60, 70, 80}

    # intersection of two sets
    print(f"s1 intersection s2 = {s1.intersection(s2)}")
    print(f"s2 intersection s1 = {s2.intersection(s1)}")
    print('-' * 80)

    # union of two sets
    print(f"s1 union s2 = {s1.union(s2)}")
    print(f"s2 union s1 = {s2.union(s1)}")
    print('-' * 80)

    # subtraction
    print(f"s1 - s2 = {s1.difference(s2)}")
    print(f"s2 - s1 = {s2.difference(s1)}")


# function2()


def function3():
    # list of strings
    students = ["amit", "rohit", "shrikant", "amit", "gopal", "amit", "shilesh"]

    # find the unique names
    unique_names = set(students)
    print(unique_names)
    unique_names.add("rahul")
    print(unique_names)


# function3()


def function4():
    # frozen set
    numbers_set = frozenset([10, 20, 30, 40, 50, 10, 20, 30, 40, 50, 10, 20, 30, 40, 50])
    print(numbers_set)

    # it CAN NOT be modified as it is immutable
    # numbers_set.add(30)

    # mutable_set = set(numbers_set)
    # mutable_set.add(100)


function4()



