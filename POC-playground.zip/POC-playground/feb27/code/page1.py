# collection
# indexing: positive and negative
# slicing:
# - getting a sequential part of collection

def function1():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

    # get values from 2 to 5 without slicing
    numbers2 = []
    for index in range(2, 6):
        numbers2.append(numbers[index])
    print(f"numbers2 = {numbers2}")

    # get values from 2 to 5 with slicing
    numbers3 = numbers[2:6]
    print(f"numbers3 = {numbers3}")


# function1()


def function2():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    print(numbers)

    # get values on even index positions without slicing
    numbers2 = []
    for index in range(0, len(numbers), 2):
        numbers2.append(numbers[index])
    print(numbers2)

    # get values on even index positions with slicing
    numbers3 = numbers[0:len(numbers):2]
    print(numbers3)


# function2()


def function3():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    print(numbers)

    # slicing scenarios
    print(f"numbers[0:5] = {numbers[0:5]}")
    print(f"numbers[5:len(numbers)] = {numbers[5:len(numbers)]}")
    print(f"numbers[0:len(numbers)] = {numbers[0:len(numbers)]}")

    # if start is missing, by default  it will be considered as 0
    print(f"numbers[:5] = {numbers[:5]}")

    # if stop is missing, by default  it will be considered as len(numbers)
    print(f"numbers[5:] = {numbers[5:]}")

    print(f"numbers[:] = {numbers[:]}")


function3()
