# aggregation
# - one-to-many relationship
# - Library has many books

class Book:
    def __init__(self, name, isbn, author):
        self.__name = name
        self.__isbn = isbn
        self.__author = author

    def print_info(self):
        print(f"| {self.__name:<30} | {self.__isbn:<10} | {self.__author:<20} |")


class Library:
    def __init__(self, name, address):
        self.__name = name
        self.__address = address

        # library has books
        self.__books = []

    def add_book(self, name, isbn, author):
        book = Book(name, isbn, author)
        self.__books.append(book)

    def print_info(self):
        print(f"name = {self.__name}")
        print(f"address = {self.__address}")
        print('--- books ---')
        for book in self.__books:
            book.print_info()


library = Library("Emtec", "pune")
library.add_book("No Excuse", "232344", "Brian Tracy")
library.add_book("Alchemist", "1232324", "Paulo Cohelio")
library.add_book("Think and Grow Rich", "21323454", "Nepolian Hill")
library.print_info()