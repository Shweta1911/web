# procedure oriented programming
# - focus is on the functionality (function)

def can_vote(person):
    if person['age'] >= 18:
        print(f"{person['name']} is eligible for voting")
    else:
        print(f"{person['name']} is NOT eligible for voting")


# dictionary
person1 = {"name": "person1", "age": 30, "address": "pune"}
person2 = {"name": "person2", "age": 10, "address": "satara"}

can_vote(person1)
can_vote(person2)

# can_vote({"model": "triber", "company": "renault"})

