# class
# - blueprint to create an object
# - collection of attributes and methods
# - types
#   - empty class
#   - concrete class

# empty class
class Person:
    pass


# print(Person)

# create an object of Person class
# person: reference
# Person: class
person = Person()

# get all attributes of person
# convert the object to a dictionary
print(person.__dict__)

# add attributes
setattr(person, "name", "person1")
setattr(person, "address", "pune")
setattr(person, "email", "person1@test.com")
print(person.__dict__)

# get attribute values
print(f"name = {getattr(person, 'name')}")
print(f"address = {getattr(person, 'address')}")
print(f"email = {getattr(person, 'email')}")


