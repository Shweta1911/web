# reuse
# - association
#   - aggregation (has-a)
#   - composition (composed-of)
# - inheritance (is-a)


# Student has-a book
# - for this example, we are using one-to-one relationship

class Book:
    def __init__(self, name, isbn, author):
        self.__name = name
        self.__isbn = isbn
        self.__author = author

    def print_info(self):
        print(f"name = {self.__name}")
        print(f"ISBN = {self.__isbn}")
        print(f"author = {self.__author}")


class Student:
    def __init__(self, roll, name, marks, book):
        self.__roll = roll
        self.__name = name
        self.__marks = marks

        # student has-a book
        self.__book = book

    def print_info(self):
        print(f"roll = {self.__roll}")
        print(f"name = {self.__name}")
        print(f"marks = {self.__marks}")
        print('-- book details --')
        self.__book.print_info()


book = Book("The monk who sold his ferrari", "122132234", "Robin Sharma")
student = Student(1, "student", 100, book)
student.print_info()
