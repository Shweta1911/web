def my_decorator(function):
    def inner_function(*args, **kwargs):
        print("calling the function")
        # pass all the parameters to the function reference
        function(*args, **kwargs)
        print("function call finished")

    return inner_function


@my_decorator
def function1(param):
    print(f"inside function1")
    print(f"param = {param}, type = {type(param)}")


function1(10)
function1(True)


@my_decorator
def function2(param1, param2):
    print(f"inside function2")
    print(f"param1 = {param1}, type = {type(param1)}")
    print(f"param2 = {param2}, type = {type(param2)}")


function2(10, 20)


def add(*args, **kwargs):
    # args is a tuple with all the parameters passed to this function
    # kwargs is a dictionary with all key-value pairs
    print(kwargs)
    total = 0
    for value in args:
        total += value

    print(f"sum of {args} = {total}")


# add(10, 20, p1=20)
# add(10, 20, p2=40, p1=20)
# add(10, 20, 30, 40)

