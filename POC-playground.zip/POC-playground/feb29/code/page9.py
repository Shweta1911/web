# import Flask class from flask package
from flask import Flask
import mysql.connector
import pymongo

# create an object of Flask class (app)
app = Flask(__name__)


# add routes
# route: mapping of url and http method
@app.route('/', methods=["GET"])
def root():
    return "hello from server"


@app.route('/employee', methods=["GET"])
def employee_list():

    # open a connection with database
    connection = mysql.connector.connect(
        user="root",
        password="root",
        port=3306,
        database="mydb",
        host="localhost")

    # create a cursor
    cursor = connection.cursor()

    # execute a query
    cursor.execute("select id, name, salary from employee")

    # get the list of employees from cursor
    employees_db = cursor.fetchall()

    # create an empty list to collect the dictionaries from tuples
    employees = []
    for tuple_emp in employees_db:
        employees.append({
            "id": tuple_emp[0],
            "name": tuple_emp[1],
            "salary": tuple_emp[2]
        })

    # close the resources
    cursor.close()
    connection.close()

    return employees


@app.route('/car', methods=["GET"])
def find_cars():
    # create pymongo client
    client = pymongo.MongoClient("mongodb://localhost:27017")

    # get the database
    db = client['mydb']

    # get the collection
    cars_collection = db['cars']

    # get the list of cars
    cars_cursor = cars_collection.find()

    cars = []
    for car in cars_cursor:
        cars.append({
            "model": car['model'],
            "company": car['company']
        })

    print(cars)

    # close the connection
    client.close()

    return cars


# run the application
app.run(host="0.0.0.0", port=4000, debug=True)

