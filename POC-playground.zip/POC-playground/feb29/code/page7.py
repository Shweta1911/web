import time


# create a closure to measure the time taken by the function
def measure_time(function):
    def inner():
        start_time = time.time()
        function()
        end_time = time.time()
        print(f"time taken by {function.__name__} is = {end_time - start_time}")

    return inner


# measure_time(function1)()
@measure_time
def function1():
    print("inside function1")
    time.sleep(3)
    print('exiting function1')


# function1()


@measure_time
def function2():
    print("inside function2")


# function2()

