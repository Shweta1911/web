# file IO
# - type
#   - text files (ascii characters) [t]: files can be read using any text editor
#   - binary files [b]: images, audio, video etc.
# - operations (modes)
#   - create (writing) - w: the content will be overwritten
#   - read (reading)   - r
#   - update (append)  - a: the content will be get appended

def function1():
    # open a file
    # - write: if the file does not exist, the file gets created first
    file = open('./my_file.txt', 'wt')

    # perform the write operation
    file.write("India is my country. All Indians are my brothers and sisters.")

    # close the file
    file.close()


# function1()


def function2():
    # open the file
    file = open('./my_file.txt', 'r')

    # perform read operation
    contents = file.read()
    print(f"contents: {contents}")

    # close the file
    file.close()


# function2()


def function3():
    # write into the file
    # with block will auto close the file
    with open("./my_file.txt", 'a') as file:
        file.write("this is the content")


# function3()


def function4():
    with open("./my_file.txt", "r") as file:
        contents = file.read()
        print(f"contents = {contents}")


# function4()


def function5():
    file1 = open('./my_file.txt', 'a')
    file2 = open('./my_file2.txt', 'r')

    contents = file2.read()
    file1.write("\n")
    file1.write(contents)

    file1.close()
    file2.close()
    

function5()
