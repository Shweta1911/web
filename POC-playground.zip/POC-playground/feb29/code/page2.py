"""
- This is called as docstring.
- This is my test module.
- This module has all mathematical operations defined.
"""

# '' or "" are used to create a single line string
# """ are used to create a multi line string
# module
# - any python file having .py extension
# - the file (module) which gets executed becomes the __main__ module


def add(p1, p2):
    print("from page2")
    print(f"{p1} + {p2} = {p1 + p2}")


def subtract(p1, p2):
    print(f"{p1} - {p2} = {p1 - p2}")


def divide(p1, p2):
    print(f"{p1} / {p2} = {p1 / p2}")


def multiply(p1, p2):
    print(f"{p1} * {p2} = {p1 * p2}")


# __name__ will return the current module name
print(f"the page2 module name = {__name__}")


def main():
    add(10, 20)
    subtract(20, 30)
    divide(100, 4)
    multiply(39, 50)


# execute the lines only when the page2 module gets executes
if __name__ == '__main__':
    main()
