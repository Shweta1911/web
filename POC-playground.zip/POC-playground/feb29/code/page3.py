# import the page2 module and consume the functionality
# package: collection of modules
# - machine learning
#   - sci-kit learn, tensorflow, pytorch, xgboost
# - testing
#   - selenium
# - web scraping
#   - ScraPy, selenium, BeautifulSoup
# - data processing
#   - numpy, pandas
# - visualization
#   - matplotlib, seaborn

print(f"the page3 module name = {__name__}")


def add(p1, p2):
    print("from page3")
    print(f"{p1} + {p2} = {p1 + p2}")


def function1():
    # import the whole module
    import page2

    page2.add(30, 40)
    page2.subtract(34, 10)
    page2.divide(40, 5)
    page2.multiply(40, 5)


# function1()


def function2():
    # import the whole module with an alias
    import page2 as p2

    p2.add(30, 40)
    p2.subtract(34, 10)
    p2.divide(40, 5)
    p2.multiply(40, 5)


# function2()


def function3():
    # import only two functions from page2
    from page2 import add, divide

    # this function will get called from page2
    add(30, 40)
    divide(40, 2)


# function3()


def function4():
    from page2 import add as my_add

    # this function will get called from page3
    add(20, 30)

    # this function will get called from page2
    my_add(40, 50)


# function4()


# import page2
# print(page2.__doc__)
