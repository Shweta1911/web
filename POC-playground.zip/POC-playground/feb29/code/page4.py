# import system module
import os

# find the attributes from the module
print(dir(os))

# find the documentation of the module
print(os.__doc__)

# read all environment variables
print(os.environ)

# delete a file
# os.unlink('./my_file.txt')

