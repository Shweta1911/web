# closure

# closure
# - function returning a inner function as return value
# outer function
def my_function():
    print("inside my_function")

    # inner function
    def inner_function():
        print("inside my_function -> inner_function")

    # return the inner function reference
    return inner_function


# returned_value will receive the reference of inner_function
returned_value = my_function()
print(returned_value)

# calling the inner function
returned_value()

# inner function can not be called outside the outer function
# inner_function()

