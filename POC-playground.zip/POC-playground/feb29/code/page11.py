# create a generator to generate prime numbers

def is_prime(num):
    for index in range(2, num):
        if num % index == 0:
            return False
    else:
        return True


def generate_prime():
    num = 2
    while True:
        if is_prime(num):
            yield num
        num += 1


generator = generate_prime()
# print(f"first prime number = {next(generator)}")
# print(f"second prime number = {next(generator)}")
# print(f"third prime number = {next(generator)}")
# print(f"forth prime number = {next(generator)}")
# print(f"fifth prime number = {next(generator)}")

for _ in range(10):
    prime_number = next(generator)
    print(prime_number)

