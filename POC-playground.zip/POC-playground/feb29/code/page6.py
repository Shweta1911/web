import time


def my_function(function):
    # function.__name__ will return the function name
    print(f"inside my_function: {function.__name__}")

    def inner_function():
        print("inside inner_function")
        start_time = time.time()
        function()
        end_time = time.time()
        print(f"time taken by function = {end_time - start_time}")

    return inner_function


def function1():
    print("inside the function1")
    time.sleep(2)
    print("existing function1....")


def function2():
    print("inside the function2")
    time.sleep(5)
    print("existing function1....")


my_function_closure = my_function(function1)
my_function_closure()

# my_function(function1)()

my_function_closure = my_function(function2)
my_function_closure()

# function1()

