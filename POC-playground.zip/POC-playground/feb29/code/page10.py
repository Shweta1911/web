
class Car:
    def __init__(self, model, company, price):
        self.__model = model
        self.__company = company
        self.__price = price

    def print_info(self):
        print(f"model = {self.__model}, company = {self.__company}, price = {self.__price}")


class Person:
    def __init__(self, name):
        self.__name = name
        self.__cars = []
        self.__index = 0

    def add_car(self, model, company, price):
        self.__cars.append(Car(model, company, price))

    def __iter__(self):
        self.__index = 0
        return self

    def __next__(self):
        if self.__index >= len(self.__cars):
            raise StopIteration()

        car = self.__cars[self.__index]
        self.__index += 1
        return car


person = Person('person1')
person.add_car("triber", "ranault", 10)
person.add_car("nano", "tata", 2)
person.add_car("compass", "zeep", 30)

# iterator = iter(person)
# print(iterator)
# car = next(iterator)
# car.print_info()


# for car in person:
#     car.print_info()


def function():
    num = 0
    for _ in range(100):
        yield num
        print("after yield")
        num += 1


generator = function()
# print(generator)
iterator = iter(generator)
# print(iterator)
print(f"first value = {next(iterator)}")
print(f"second value = {next(iterator)}")
# for value in generator:
#     print(f"value = {value}")

