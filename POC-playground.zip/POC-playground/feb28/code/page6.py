# multiple
# - one derived class having multiple base classes

# class Teacher(object):
# class Teacher():
class Teacher:
    def __init__(self, name, subject):
        self._name = name
        self._subject = subject

    def print_info(self):
        print(f"Teacher [name={self._name}, subject={self._subject}]")


class LabAssistant:
    def __init__(self, name, session):
        self._name = name
        self._session = session

    def print_info(self):
        print(f"LabAssistant [name={self._name}, session={self._session}]")


class TeacherLabAssistant(Teacher, LabAssistant):
    def __init__(self, name, subject, session):
        # super(name, subject)
        Teacher.__init__(self, name, subject)
        LabAssistant.__init__(self, name, session)

    def print_info(self):
        print(f"name = {self._name}")
        # super().print_info()

        Teacher.print_info(self)
        LabAssistant.print_info(self)

        # print(f"subject = {self._subject}")
        # print(f"session = {self._session}")


print(TeacherLabAssistant.__bases__)

tla = TeacherLabAssistant("tla", "computer", "afternoon")
tla.print_info()