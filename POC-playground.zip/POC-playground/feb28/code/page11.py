# for..in..else

def function1():
    # find if the number is prime
    num = int(input("enter a number: "))

    is_prime = True
    for index in range(2, num):
        if num % index == 0:
            is_prime = False
            break

    if is_prime:
        print(f"{num} is Prime")
    else:
        print(f"{num} is NOT prime")


# function1()


def function2():
    # find if the number is prime
    num = int(input("enter a number: "))

    for index in range(2, num):
        if num % index == 0:
            print(f"{num} is NOT prime")
            break
    else:
        print(f"{num} is prime")


function2()
