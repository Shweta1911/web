# inheritance (is-a)
# - a class inherits the public and protected attributes from another class
# - the child class derives or inherits all public and protected attributes
#   from parent class
# note
# - all the classes are derived from object directly or indirectly from python 3.x
# object
# - system class: provided by Python
# - root class in python
# - it provides basis properties of an object and memory management functionality
# types
# - single or simple
# - multilevel
# - multiple
# - hierarchical
# - hybrid


# Person class is super/base class of Employee
# Person class is direct subclass or object
# object is direct base class of Person
class Person:
    pass


# Employee is-a Person
# Employee is derived from Person class
# Employee is inherited from Person class
# Employee is subclass/derived of Person class
# Employee is derived from object indirectly
class Employee(Person):
    pass


print(f"super class of Employee = {Employee.__base__}")
print(f"super class of Person = {Person.__base__}")
