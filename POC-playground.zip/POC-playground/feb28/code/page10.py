# iterable
# - the object which can be iterated
# iterator
# - used to iterate an iterable object

class School:
    def __init__(self, name):
        self.__students = []
        self.__name = name
        self.__index = 0

    def add_student(self, name):
        self.__students.append(name)

    # is called internally when iter is used on school object
    def __iter__(self):
        # reset the index
        self.__index = 0
        return self

    def __next__(self):
        if self.__index >= len(self.__students):
            raise StopIteration()

        value = self.__students[self.__index]
        self.__index += 1
        return value


def function1():
    # list of numbers
    # list is iterable
    numbers = [10, 20, 30, 40, 50]

    # get the iterator of collection
    iterator = iter(numbers)

    # use iterator to get the values one by one
    try:
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
        print(f"next value = {next(iterator)}")
    except StopIteration:
        print("no number is left to iterate")

    # for number in numbers:
    #     print(f"number = {number}")


# function1()


def function2():
    school = School("school 1")
    school.add_student("student 1")
    school.add_student("student 2")
    school.add_student("student 3")
    school.add_student("student 4")
    school.add_student("student 5")

    # get the iterator from school
    # iter function will call school.__iter__()
    iterator = iter(school)
    print(iterator)

    # next() calls the iterator.__next__()
    # try:
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    #     print(f"next value = {next(iterator)}")
    # except StopIteration:
    #     print("no student left to iterate")

    for student in school:
        print(f"student = {student}")


function2()


