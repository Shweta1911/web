# Hierarchical inheritance


class Person:
    def __init__(self, name):
        self._name = name

    def print_info(self):
        print(f"name = {self._name}")


class Employee(Person):
    def __init__(self, emp_id, name):
        Person.__init__(self, name)
        self._emp_id = emp_id

    def print_info(self):
        print(f"id = {self._emp_id}")
        # calling the base class method
        Person.print_info(self)
        # super().print_info()


class Student(Person):
    def __init__(self, roll, name):
        Person.__init__(self, name)
        self.__roll = roll

    def print_info(self):
        print(f"roll = {self.__roll}")
        Person.print_info(self)


class Player(Person):
    def __init__(self, team, name):
        Person.__init__(self, name)
        self.__team = team

    def print_info(self):
        print(f"team = {self.__team}")
        Person.print_info(self)
