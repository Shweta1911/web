# multi-level inheritance

class Person:
    def __init__(self, name):
        self._name = name

    def print_info(self):
        print(f"name = {self._name}")


class Employee(Person):
    def __init__(self, emp_id, name):
        Person.__init__(self, name)
        self._emp_id = emp_id

    def print_info(self):
        print(f"id = {self._emp_id}")
        # calling the base class method
        Person.print_info(self)
        # super().print_info()


class Manager(Employee):
    def __init__(self, emp_id, name, department):
        Employee.__init__(self, emp_id, name)
        self.__department = department

    def print_info(self):
        print(f"department = {self.__department}")
        Employee.print_info(self)


person = Person("person1")
person.print_info()

print()

employee = Employee(1, "employee 1")
employee.print_info()

print()

manager = Manager(2, "manager 2", "Accounting")
manager.print_info()