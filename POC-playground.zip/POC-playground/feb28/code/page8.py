# operator overloading
# - magical methods

class Number:
    def __init__(self, value):
        self.__value = value
        
    def __str__(self):
        return f"Number[value={self.__value}]"

    def __add__(self, other):
        return Number(self.__value + other.__value)

    def __sub__(self, other):
        return Number(self.__value - other.__value)

    def __mul__(self, other):
        return Number(self.__value * other.__value)

    def __truediv__(self, other):
        return Number(self.__value / other.__value)

    def __floordiv__(self, other):
        return Number(self.__value // other.__value)

    def __pow__(self, power, modulo=None):
        return Number(self.__value ** power)

    def __eq__(self, other):
        return self.__value == other.__value

    def __gt__(self, other):
        return self.__value > other.__value

    def __ge__(self, other):
        return self.__value >= other.__value

    def __lt__(self, other):
        return self.__value < other.__value

    def __le__(self, other):
        return self.__value <= other.__value

    def __ne__(self, other):
        return self.__value != other.__value


def function1():
    # int
    num1, num2 = 100, 200
    print(f"num1 + num2 = {num1 + num2}")
    print(f"num1 + num2 = {num1.__add__(num2)}")

    # str
    str1, str2 = "hello", 'hell'
    print(f"str1 + str2 = {str1 + str2}")
    print(f"str1 + str2 = {str1.__add__(str2)}")


# function1()


def function2():
    n1 = Number(100)
    n2 = Number(200)

    print(f"n1 = {n1}, n2 = {n2}")
    # print(f"n1 + n2 = {n1.__add__(n2)}")
    print(f"n1 + n2 = {n1 + n2}")
    print(f"n1 - n2 = {n1 - n2}")
    print(f"n1 * n2 = {n1 * n2}")
    print(f"n1 / n2 = {n1 / n2}")
    print(f"n1 // n2 = {n1 // n2}")
    print(f"n1 ** n2 = {n1 ** 2}")
    print()
    print(f"n1 == n2 = {n1 == n2}")
    print(f"n1 > n2 = {n1 > n2}")
    print(f"n1 >= n2 = {n1 >= n2}")
    print(f"n1 < n2 = {n1 < n2}")
    print(f"n1 <= n2 = {n1 <= n2}")
    print(f"n1 != n2 = {n1 != n2}")


function2()

