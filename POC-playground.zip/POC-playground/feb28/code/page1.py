# association - aggregation
# - weak relationship
# - Person has-an Address and Company has-an address

class Address:
    def __init__(self, city, state, country, zip_code):
        self.__city = city
        self.__state = state
        self.__country = country
        self.__zip_code = zip_code

    def print_address(self):
        print(f"{self.__city}, {self.__state}, {self.__country}, {self.__zip_code}")


class Person:
    def __init__(self, name, age, address):
        self.__name = name
        self.__age = age

        # person has-an address
        self.__address = address

    def print_info(self):
        print(f"name = {self.__name}")
        print(f"age = {self.__age}")
        print("-- address --")
        self.__address.print_address()


class Company:
    def __init__(self, name, address):
        self.__name = name

        # company has-an address
        self.__address = address

    def print_info(self):
        print(f"name = {self.__name}")
        print("-- address --")
        self.__address.print_address()


person_address = Address("pune", "MH", "India", 411041)
person = Person("person1", 30, person_address)
person.print_info()

print("-" * 80)

company_address = Address("mumbai", "MH", "India", 439854)
company = Company("company 1", company_address)
company.print_info()
