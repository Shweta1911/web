# exception handling
# - Exception: run time event
# - types
#   - error:
#     - unavoidable or can NOT be handled
#     - bad sector, not enough memory etc.
#   - exception
#     - can be handled
# handling
# - finding alternative to avoid the application crash
# - using try..except block

# type casting
# - int, float, str, bool, list, tuple, set, frozen_set etc.

def function1():
    try:
        num1 = int(input("enter first number: "))
        num2 = int(input("enter second number: "))

        # write the code which may raise exception(s)
        division = num1 / num2
    except ZeroDivisionError:
        print("the ZeroDivisionError except block is called")
    except ValueError:
        print("the ValueError except block is called")
    except:
        # generic except block
        # - can handle any type of exception
        # - must be present at the end of the except block list
        # - only one generic except block is permitted
        print("the generic except block is called")
    else:
        # will be called only when there is no exception raised
        print("else block called")
        print(f"division = {division}")
    finally:
        print("finally block called")


# function1()


# custom exception
class InvalidAgeError(Exception):
    def __init__(self, age):
        Exception.__init__(self, "invalid age")
        self.__age = age

    def get_age(self):
        return self.__age


def function2():
    age = int(input("enter age: "))
    if (age < 20) or (age > 60):
        # raise an object of InvalidAgeError
        raise InvalidAgeError(age)

    print(f"age = {age}")


try:
    function2()
except InvalidAgeError as ex:
    print(f"age = {ex.get_age()}")
    print("invalid age error exception handled")




