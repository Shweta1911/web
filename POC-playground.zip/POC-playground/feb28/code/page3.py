# simple or single inheritance

class Person:
    def __init__(self, name, age):
        self._name = name
        self._age = age

    def print_info(self):
        print("inside Person")
        print(f"name = {self._name}, age = {self._age}")


class Employee(Person):
    def __init__(self, emp_id, name, age):
        # crate an object of base class (Person)
        Person.__init__(self, name, age)
        # super(name, age)
        self.__id = emp_id

    # Employee class is overriding the print_info() method
    def print_info(self):
        print("inside Employee")
        print(f"id = {self.__id}")
        print(f"name = {self._name}")
        print(f"age = {self._age}")


person = Person("person1", 30)
person.print_info()
# conventionally one should not update/access the protected members outside the class
# person._name = "test"
person.print_info()


employee = Employee(1, "employee 1", 40,)
employee.print_info()



