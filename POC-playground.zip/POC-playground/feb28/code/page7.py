class Person:
    def __init__(self, name):
        self.name = name

    def __str__(self):
        # convert the object into string format
        return f"Person[name={self.name}]"


def function1():
    # int
    num = 100
    print(f"num = {num.__str__()}, type = {type(num)}")
    print(f"num = {num}, type = {type(num)}")

    print()

    # Person
    person = Person('person1')
    print(f"person = {person.__str__()}, type = {type(person)}")
    print(f"person = {person}, type = {type(person)}")


function1()
