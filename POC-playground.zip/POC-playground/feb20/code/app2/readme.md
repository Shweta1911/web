# Requirements

## User

- POST /user/register
- POST /user/login
- PUT /user/
- DELETE /user

## Todo Item

- POST /item
- GET /item
- PUT /item
- DELETE /item

## Categories

- POST /category
- GET /category
- PUT /category
- DELETE /category
