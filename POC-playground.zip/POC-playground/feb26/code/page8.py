# indexing
# - getting value from collection using index position
# - types
#   - positive indexing
#     - index starts from left and will increase toward right
#     - the first value will have an index of 0
#   - negative indexing
#     - index starts from right
#     - the last value will have an index of -1

def function1():
    # list of numbers
    numbers = [10, 20, 30, 40, 50]

    # using positive indexing
    print(f"value at first index = {numbers[0]}")
    print(f"value at last index = {numbers[len(numbers) - 1]}")

    # using negative indexing
    print(f"value at first index = {numbers[-len(numbers)]}")
    print(f"value at -2 index = {numbers[-2]}")
    print(f"value at -4 index = {numbers[-4]}")
    print(f"value at last index = {numbers[-1]}")

    # print(f"value at first index = {numbers[len(numbers) - len(numbers)]}")
    # print(f"value at -2 index = {numbers[len(numbers) - 2]}")
    # print(f"value at -4 index = {numbers[len(numbers) - 4]}")
    # print(f"value at last index = {numbers[len(numbers) - 1]}")


function1()

