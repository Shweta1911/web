# function
# - set of instructions (block) which can be reused
# - can not separate function declaration from definition
# types
# - based on body => empty, non-empty
# - based on the placement => outer, inner (local)
# - based on parameters => parameterless, parameterized
# - based on the function name => named, unnamed / anonymous (lambda)

# pass
# - NO_OP: No Operation

# empty function
# parameterless
def empty_function():
    pass


# non-empty function
# parameterless function
def function1():
    print("inside function1")


# function call
# function1()


# parameterized function
def function2(param1: int):
    print(f"inside function2")
    print(f"param = {param1}, type = {type(param1)}")


# function2(10)
# function2("steve")
# function2(True)
# function2(None)

def add(p1: int, p2: int):
    result = p1 + p2
    print(f"result = {result}")


# add(10, 10)
# add("10", "10")
# add(10, "10")

# lambda
# - anonymous function
# - works like inline function of C
# - rules
#   - accept at least on parameter
#   - must contain only one statement in the body
#   - body must return a value
# def square(num: int):
#     return num ** 2
square = lambda num: num ** 2
print(f"square of 4 = {square(4)}")

