# variables
# - all data types are inferred
# - assign the data types to the variables inspecting the values stored in them

# variable named num storing value 100 in memory
# data type = integer (int)
num = 100
print(f"num = {num}, type = {type(num)}")

# data type = float (float)
salary = 15.50
print(f"salary = {salary}, type = {type(salary)}")

# data type = string (str)
first_name = 'Steve'
print(f"first name = {first_name}, type = {type(first_name)}")

last_name = "Jobs"
print(f"last name = {last_name}, type = {type(last_name)}")

# data type = boolean (bool)
can_vote = True
print(f"can_vote = {can_vote}, type = {type(can_vote)}")


# data type suggestion (type inference)
# - used by IDEs
myname: str = "amit"
print(f"myname = {myname}, type = {type(myname)}")

# data type = int
myvar: str = 100
print(f"myvar = {myvar}, type = {type(myvar)}")
