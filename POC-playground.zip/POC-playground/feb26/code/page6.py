# collection
# - dynamic collection of values
# - collection size can be modified
# - types
#   - list
#   - tuple
#   - set
#   - dictionary

# list
# - of sequential data types
# - collection of value (homogeneous or non-homogeneous)
# - indefinite size (size gets updated dynamically)
# - duplicate values are allowed
# - insert order is maintained
# - use [] to create a list object
# - mutable collection: updated dynamically

def function1():
    # empty list
    # - preferred when a new object is created
    list1 = []
    print(f"list1 = {list1}, type = {type(list1)}")

    # empty list using list()
    # - list() is used to type case other type of collection to list
    list2 = list([])
    print(f"list2 = {list2}, type = {type(list2)}")


# function1()


def function2():
    # list of integers
    numbers = [10, 20, 30, 40, 50, 10, 20, 30, 40, 50]
    print(f"numbers = {numbers}, type = {type(numbers)}")

    # list of string values
    countries = ["india", "usa", "uk", "japan"]
    print(f"countries = {countries}, type = {type(countries)}")

    # list of non-homogeneous values
    mixed_list = [True, "steve", 10, 15.50, False, 200, "Jobs"]
    print(f"mixed_list = {mixed_list}, type = {type(mixed_list)}")


# function2()

def function3():
    # list of numbers
    numbers = [10, 20, 30, 40, 50]
    print(numbers)

    # add a new value at the end of the list
    numbers.append(60)
    print(numbers)

    numbers.append(70)
    print(numbers)

    # add value 15 between 10 and 20
    numbers.insert(1, 15)
    print(numbers)

    # add value 25 between 20 and 30
    numbers.insert(3, 25)
    print(numbers)

    # add value 5 at the beginning of the collection
    numbers.insert(0, 5)
    print(numbers)


# function3()


def function4():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 20, 30, 20, 40, 20]
    print(numbers)

    # remove the last value using pop()
    removed_value = numbers.pop()
    print(f"removed value = {removed_value}")
    print(numbers)

    # remove value at an index
    removed_value = numbers.pop(2)
    print(f"removed value = {removed_value}")
    print(numbers)

    # remove value using value (not using index)
    # this method will remove only first occurrence of the value
    numbers.remove(20)
    print(numbers)

    # remove all values from numbers
    numbers.clear()
    print(numbers)


# function4()


def function5():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 30, 20, 40, 50, 20, 10, 40]
    print(numbers)

    # len is used to get the length of collection
    print(f"size of numbers = {len(numbers)}")

    # find the number of occurrences of a value
    count_20 = numbers.count(20)
    print(f"20 appears {count_20} times")

    for _ in range(count_20):
        numbers.remove(20)

    print(numbers)


# function5()


def function6():
    # list of numbers
    numbers = [10, 20, 30, 40, 50, 30, 20, 40, 50, 20, 10, 40, 20, 40, 50, 20]
    print(numbers)

    # find the index of first occurrence of the value in the collection
    # print(f"value 20 exists on {numbers.index(20)} index")
    # print(f"value 20 exists on {numbers.index(20, 2)} index")
    # print(f"value 20 exists on {numbers.index(20, 7)} index")

    index_20 = []
    start_search_index = 0
    for _ in range(numbers.count(20)):
        start_search_index = numbers.index(20, start_search_index)
        index_20.append(start_search_index)
        start_search_index += 1
    print(f"found 20 on index = {index_20}")


# function6()


def function7():
    # list of numbers
    numbers1 = [10, 20, 30]
    numbers2 = [40, 50, 60]

    # append the values of numbers2 to numbers1
    numbers1.extend(numbers2)
    print(numbers1)

    
function7()
