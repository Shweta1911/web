# tuple
# - collection of homogeneous or non-homogeneous values
# - immutable collection: once created, CAN NOT be modified
# - allows duplicate values
# - maintains the insertion order
# - use () to create a tuple

def function1():
    # list of numbers
    numbers1 = [10, 20, 30, 40, 50]
    print(f"numbers1 = {numbers1}, type = {type(numbers1)}")

    # tuple of numbers
    numbers2 = (10, 20, 30, 40, 50)
    print(f"numbers2 = {numbers2}, type = {type(numbers2)}")

    # tuple of numbers
    numbers3 = 10, 20, 30, 40, 50
    print(f"numbers3 = {numbers3}, type = {type(numbers3)}")


# function1()


def function2():
    # empty list
    numbers1 = []
    print(f"numbers1 = {numbers1}, type = {type(numbers1)}")

    # empty tuple
    numbers2 = ()
    print(f"numbers2 = {numbers2}, type = {type(numbers2)}")

    # list with one value
    numbers3 = [10]
    print(f"numbers3 = {numbers3}, type = {type(numbers3)}")

    # does not create tuple with one value
    # rather this will create a string variable
    # numbers4 = ("test")
    # print(f"numbers4 = {numbers4}, type = {type(numbers4)}")

    # tuple with one value
    numbers5 = (10, )
    print(f"numbers5 = {numbers5}, type = {type(numbers5)}")


# function2()


def function3():
    # tuple of numbers
    numbers = (10, 20, 30)

    # create 3 variables to hold the values from numbers tuple
    # n1 = numbers[0]
    # n2 = numbers[1]
    # n3 = numbers[2]
    # print(f"n1 = {n1}, n2 = {n2}, n3 = {n3}")

    # create 3 variables to hold the values from numbers tuple
    # tuple unpacking
    # n1, n2, n3 = numbers
    # n1, n2, n3 = (10, 20, 30)
    n1, n2, n3 = 10, 20, 30
    print(f"n1 = {n1}, n2 = {n2}, n3 = {n3}")

    # both the following statements will crash
    # p1, p2 = 10, 20, 30, 40, 50
    # p1, p2, p3 = 10, 20

    # collect the first value in p1, second value in p2
    # rest of the values in p3
    # p1, p2, *p3 = 10, 20, 30, 40, 50
    # print(f"p1 = {p1}, p2 = {p2}, p3 = {p3}")

    p1, *p2, p3 = 10, 20, 30, 40, 50
    print(f"p1 = {p1}, p2 = {p2}, p3 = {p3}")


# function3()


def function4():
    # tuple unpacking
    num1, num2 = 10, 20
    print(f"num1 = {num1}, num2 = {num2}")

    # swap the values
    num1, num2 = num2, num1
    print(f"num1 = {num1}, num2 = {num2}")


# function4()


def perform_math_operations(p1: int, p2: int):
    addition = p1 + p2
    subtraction = p1 - p2
    division = p1 / p2
    multiplication = p1 * p2

    # this function is returning a tuple of values
    # tuple packing
    return addition, subtraction, division, multiplication


# tuple unpacking
# a, s, d, m = perform_math_operations(10, 20)
# print(f"addition = {a}, subtract = {s}, division = {d}, multiplication = {m}")


def function5():
    # tuple of numbers
    numbers = 10, 20, 30, 40, 50

    # CAN NOT append a value
    # numbers.append(60)

    # CAN NOT remove the last value
    # numbers.pop()

    # get the number of occurrences of a values
    print(f"20 occurred {numbers.count(20)} times")

    # get the index of first occurrence of a values
    print(f"20 occurred at {numbers.index(20)} index")


function5()
