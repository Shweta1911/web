# function reference
# - reference to  function

def function1():
    print("inside function1")


# function1()
print(f"function1 = {function1}")
print(f"type of function1 = {type(function1)}")

# function reference
my_function1 = function1
function1()
my_function1()
