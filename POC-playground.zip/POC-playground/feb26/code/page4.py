# scope
# - local: declared inside a function
# - global: declared outside of any function

# global
num = 100
print(f"1. outside any function num = {num}")


def function1():
    # it creates a local copy of global variable
    num = 400

    print("inside function1")
    print(f"num = {num}")


# function1()


def function2():
    print("inside function2")

    # local scoped variable
    my_var = "test"
    print(f"my_var = {my_var}")

    # explicitly use the global variable
    # do not create any local copy of global num
    global num
    num = 400
    print(f"num = {num}")


function2()


print(f"2. outside any function num = {num}")

# can not access my_var as its local variable of function2
# print(f"2. outside any function my_var = {my_var}")
