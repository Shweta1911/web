# nested or local or inner function

def function1():
    print("inside function1")

    # local
    num = 100
    print(f"num = {num}, type = {type(num)}")

    # local scope
    def inner_function1():
        print("inside inner_function")

    # can call the inner_function inside the function1
    inner_function1()


# function1()

# can not access both inner_function1 and num as they are
# the local members of function1
# inner_function1()
# print(f"outside function1, num = {num}")


def outer_function():
    print("inside outer_function")

    # local variable of outer_function
    num = 100
    print(f"num = {num}, type = {type(num)}")

    def inner_function():
        print("inside inner_function")

        # it can access all the local members of outer function
        print(f"num = {num}, type = {type(num)}")

        # local variable declared by inner_function
        my_var = "test"
        print(f"my_var = {my_var}, type = {type(my_var)}")

    inner_function()

    # outer function CAN NOT access anything declared locally inside inner function
    # print(f"my_var = {my_var}, type = {type(my_var)}")


outer_function()

