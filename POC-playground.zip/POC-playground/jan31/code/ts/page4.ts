// Object function

// create a new object of type Object
const person = new Object()
person['name'] = 'person1'
person['address'] = 'pune'
person['phone'] = '+91243242'
console.log(person)
console.log(`type of person = ${typeof person}`)
