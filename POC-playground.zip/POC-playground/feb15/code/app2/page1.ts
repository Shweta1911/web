// Square
// Circle

// this is a  very bad design
function calculateArea(type) {
  if (type == 'square') {
    console.log(`calculating area of square`)
  } else if (type == 'circle') {
    console.log(`calculating area of circle`)
  }
}
