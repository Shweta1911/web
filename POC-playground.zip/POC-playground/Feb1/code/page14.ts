// e-commerce
// - user
// - order
//   - id, userId, date, total
//   - 101,  1, feb 1, 800
// - orderDetails
//   - id, orderId, productId, price, quantity
//   - 110, 101, 1, 100, 2
//   - 111, 101, 2, 200, 3
// - product
//   - id, title, brand, price
//   - CosmeticProduct
//     - color, shape,
//   - Mobile
//     - cpu, gpu, storage, display
// - cart

// - userId, productId, price, quantity
// - 1, 1, 100, 2 = 200
// - 1, 2, 200, 3 = 600
//
