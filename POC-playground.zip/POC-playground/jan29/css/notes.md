# Bootstrap

- library
  - uses single language
- framework
  - uses multiple languages
  - collection of libraries / classes / functions / css classes
- Bootstrap
  - framework which has many pre-defined css classes and JS libraries (functions)
  - free and open source
  - responsive websites
