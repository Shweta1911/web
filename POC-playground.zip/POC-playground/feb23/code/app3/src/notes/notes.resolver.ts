import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import { NotesType } from './types/notes.type';
import { NotesService } from './notes.service';
import { CreateNoteInputType } from './types/create.note.inputtype';

@Resolver((of) => NotesType)
export class NotesResolver {
  constructor(private service: NotesService) {}

  @Query((returns) => [NotesType])
  notes() {
    return this.service.getNotes();
  }

  @Mutation((returns) => NotesType)
  createNote(@Args('input') input: CreateNoteInputType) {
    const { title, description } = input;
    return this.service.createNote(title, description);
  }
}
