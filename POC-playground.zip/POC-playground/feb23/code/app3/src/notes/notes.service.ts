import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { NotesEntity } from './notes.entity';
import { Repository } from 'typeorm';

@Injectable()
export class NotesService {
  constructor(
    @InjectRepository(NotesEntity)
    private repository: Repository<NotesEntity>,
  ) {}

  async getNotes() {
    try {
      const notes = await this.repository.find();
      return notes;
    } catch (ex) {
      console.log(ex);
      throw new InternalServerErrorException(ex);
    }
  }

  async createNote(title: String, description: String) {
    try {
      const note = new NotesEntity();
      note.title = title;
      note.description = description;
      note.status = false;
      await this.repository.save(note);
      return note;
    } catch (ex) {
      console.log(ex);
      throw new InternalServerErrorException(ex);
    }
  }
}
