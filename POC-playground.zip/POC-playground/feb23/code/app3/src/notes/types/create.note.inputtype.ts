import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class CreateNoteInputType {
  @Field()
  title: String;

  @Field()
  description: String;
}
