import { Field, ID, ObjectType } from '@nestjs/graphql';

@ObjectType()
export class NotesType {
  @Field((type) => ID)
  id: Number;

  @Field()
  title: String;

  @Field()
  description: String;

  @Field()
  status: Boolean;
}
