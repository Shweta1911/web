import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity('product')
export class ProductEntity {
  @PrimaryColumn()
  _id: String;

  @Column()
  title: String;

  @Column()
  description: String;

  @Column()
  price: Number;

  @Column()
  company: String;

  @Column()
  category: String;

  @Column()
  color: String;
}
